using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIResultInfo : MonoBehaviour
{
	[SerializeField] private GameObject enrowBackgroundImage = null;
	[SerializeField] private GameObject worldChampionshipImage = null;
	[SerializeField] private TextMeshProUGUI worldChampionshipText = null;
	[SerializeField] private GameObject middleChampionshipImage = null;
	[SerializeField] private TextMeshProUGUI middleChampionshipText = null;
	[SerializeField] private List<Image> ratingStarImage = null;
	[SerializeField] private TextMeshProUGUI eventDateText = null;
	[SerializeField] private TextMeshProUGUI eventNameText = null;
	[SerializeField] private TextMeshProUGUI opponentNameText = null;
	[SerializeField] private Image resultTagImage = null;
	[SerializeField] private TextMeshProUGUI resultTagText = null;

	[SerializeField] private Sprite resultWinSprite = null;
	[SerializeField] private Sprite resultLossSprite = null;
	[SerializeField] private Sprite ratingEmptySprite = null;
	[SerializeField] private Sprite ratingHalfSprite = null;
	[SerializeField] private Sprite ratingFullSprite = null;


	public bool Init(PromotionResultInfo result, int nIndex)
	{
		if (result == null)
		{
			print("Result is null.");
			return false;
		}

		if (nIndex % 2 != 0)
			enrowBackgroundImage.SetActive(true);
		else
			enrowBackgroundImage.SetActive(false);

		eventDateText.text = DateManager.instance.GetDateFromTotalDays(result.totalDays).ToString("M/d");
		eventNameText.text = result.eventName;
		opponentNameText.text = result.opponent;

        switch ((Enums.PromotionType)result.mode)
        {
			case Enums.PromotionType.MATCH:
				if (result.won)
				{
					resultTagText.text = LanguageDataManager.instance.LangWorldText("win");
					resultTagImage.sprite = resultWinSprite;
				}
				else
				{
					resultTagText.text = LanguageDataManager.instance.LangWorldText("loss");
					resultTagImage.sprite = resultLossSprite;
				}
				break;

			case Enums.PromotionType.PROMO:
				resultTagText.text = LanguageDataManager.instance.LangWorldText("promo");
				resultTagImage.sprite = resultWinSprite;
				break;

			default:
                return false;
        }
        

		switch(result.championlevel)
        {
			case 1:
				worldChampionshipImage.SetActive(true);
				worldChampionshipText.text = LanguageDataManager.instance.LangWorldText("world_championship");
				middleChampionshipImage.SetActive(false);
				break;

			case 2:
				middleChampionshipImage.SetActive(true);
				middleChampionshipText.text = result.eventName + " " + LanguageDataManager.instance.LangWorldText("middle_championship");
				worldChampionshipImage.SetActive(false);
				break;

			default:
				worldChampionshipImage.SetActive(false);
				middleChampionshipImage.SetActive(false);
				break;
		}

		int __rating = (int)(result.score * 10);
		int __fullStars = __rating / 10;
		bool __halfStar = (__rating % 10) / 5 == 1;
		foreach (var __star in ratingStarImage)
		{
			__star.sprite = ratingEmptySprite;
		}
		int __index;
		for (__index = 0; __index < __fullStars; __index++)
		{
			ratingStarImage[__index].sprite = ratingFullSprite;
		}
		if (__halfStar)
		{
			ratingStarImage[__index].sprite = ratingHalfSprite;
		}

		return true;
	}
}
