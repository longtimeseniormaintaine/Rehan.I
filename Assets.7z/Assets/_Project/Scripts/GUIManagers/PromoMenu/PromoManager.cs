﻿using UnityEngine;
using System;
using TMPro;

public class PromoManager : LanguageCtrl
{
    public Action goToHome;
    public Action goToWorld;
    
    [SerializeField] GameObject _promoMenu = null;
    [SerializeField] PromoMinigameManager _minigameManager = null;
    [SerializeField] PromoRatingManager _ratingManager = null;
    [SerializeField] PromoFeedbackManager _feedbackManager = null;
    [SerializeField] PromoStatsManager _statsManager = null;
    [SerializeField] PromoLevelUpManager _levelUpManager = null;
    [SerializeField] MatchProgressRewardManager _progressRewardManager = null;
    [SerializeField] PromoUnlockPromotionManager _unlockPromotionManager = null;
    [SerializeField] MatchPromoterFeedbackManager _promoterFeedbackManager = null;
    [SerializeField] GameObject _noMoroPromotionsDialog = null;


    [Header("Headlines")]
    [SerializeField] UIHeadlinePlayer _playerHeadline = null;
    [SerializeField] UIHeadlineDate _dateHeadline = null;

    [Header("Data")]
    [SerializeField] PromoInfo _promoInfo = null;

    [Header("Texts for Language")]
    [SerializeField] TextMeshProUGUI _getmorebooking_title;
    [SerializeField] TextMeshProUGUI _getmorebooking_description;
    [SerializeField] TextMeshProUGUI _yes_btn;
    [SerializeField] TextMeshProUGUI _no_btn;

    float _promoRating;

    public override void LangSelect()
    {
        _getmorebooking_title.text = LanguageDataManager.instance.LangMatchText("getmorebooking_title");
        _getmorebooking_description.text = LanguageDataManager.instance.LangMatchText("getmorebooking_description");
        _yes_btn.text = LanguageDataManager.instance.LangMatchText("yes_btn");
        _no_btn.text = LanguageDataManager.instance.LangMatchText("no_btn");
    }

    public void Kinitialize()
    {
        _minigameManager.minigameResult += MinigameResult;
        _ratingManager.retryMatch += RetryMatch;
        _ratingManager.proceed += ProceedFromRating;
        _feedbackManager.next += NextFromFeedback;
        _statsManager.next += NextFromStats;
        _levelUpManager.next += NextFromLevelup;
        _progressRewardManager.next += NextFromProgressReward;
        _unlockPromotionManager.next += NextFromUnlockPromotion;
        _promoterFeedbackManager.onNextButtonClicked += OnPromoterFeedbackNextButtonClicked;
        _minigameManager.KInitialize();
        _ratingManager.KInitialize();
    }

    public void KUpdate()
    {
        _minigameManager.KUpdate();
        _statsManager.KUpdate();
        _feedbackManager.KUpdate();
        _unlockPromotionManager.KUpdate();
        _levelUpManager.KUpdate();
    }

    public void Start()
    {
        LangSelect();
    }

    public void KOnEnable()
    {
        
        _minigameManager.Activate(_promoInfo);
        _ratingManager.Deactivate();
        _feedbackManager.Deactivate();
        _statsManager.Deactivate();
        _levelUpManager.Deactivate();
        _progressRewardManager.Deactivate();
        _unlockPromotionManager.Deactivate();
        _promoterFeedbackManager.Deactivate();
        _noMoroPromotionsDialog.gameObject.SetActive(false);

        _playerHeadline.UpdateContent();
        _dateHeadline.UpdateContent();

        _promoMenu.SetActive(true);
    }

    public void KOnDisable()
    {
        _promoMenu.SetActive(false);
    }

    void MinigameResult(float p_rating)
    {
        Debug.Log("show promo rating " + p_rating);
        _promoRating = p_rating;
        _minigameManager.Deactivate();
        _ratingManager.Activate(_promoRating, _promoInfo.promotion.contractPosition, _promoInfo.promotion.playerIsChampion);
    }

    void RetryMatch()
    {
        _ratingManager.Deactivate();
        _minigameManager.Activate(_promoInfo);
    }

    void ProceedFromRating()
    {
        _ratingManager.Deactivate();

        _promoInfo.promotion.AddShowRating(_promoRating);
        int nLevel = 0;
        if (_promoInfo.opponent.isChampion == true || _promoInfo.promotion.playerIsChampion == true)
            nLevel = 1;
        if (_promoInfo.opponent.isMidTitleChampion == true || _promoInfo.promotion.playerIsMidTitleChampion == true)
            nLevel = 2;

        _promoInfo.promotion.AddShowResult(_promoRating, _promoInfo.opponent.wrestlerData, DateManager.instance.GetDate(), _promoInfo.promotion.eventName, (int)Enums.PromotionType.PROMO, (_promoRating >= 5) ? true : false, nLevel);

        _feedbackManager.Activate(_promoRating, _promoInfo);
    }

    void NextFromFeedback()
    {
        _feedbackManager.Deactivate();
        _statsManager.Activate(_promoRating, _promoInfo);
    }

    void NextFromStats()
    {
        _statsManager.Deactivate();
        
        if (PlayerDataManager.instance.playerData.hasLeveledUp)
        {
            _levelUpManager.Activate();
        }
        else 
        {
            ExitEvent();
        }
    }

    void NextFromLevelup()
    {
        _levelUpManager.Deactivate();
        
        if (PromotionDataManager.instance.CheckIfUnlockedNewPromotion())
        {
            _unlockPromotionManager.Activate();
        }
        else
        {
            if (LevelProgressionDataManager.instance.GotPerks)
            {
                _progressRewardManager.Activate();
            }
            else
            {
                ExitEvent();
            }
        }
        
    }

    void NextFromProgressReward() 
    {
        _progressRewardManager.Deactivate();
        _playerHeadline.UpdateContent();
        ExitEvent();
    }

    void NextFromUnlockPromotion()
    {   
        _unlockPromotionManager.Deactivate();
        
        if (LevelProgressionDataManager.instance.GotPerks)
        {
            _progressRewardManager.Activate();
        }
        else
        {
            ExitEvent();
        }
    }

    void ExitEvent()
    {
        // Promo payment.
        PlayerDataManager.instance.playerData.money += _promoInfo.promotion.contractPayPerMatch;
        _promoInfo.promotion.contractDaysLeft--;
        SFXPlayerManager.instance.PlayMoneySFX();
        
        // match or promo repetition.
        if (!PlayerDataManager.instance.playerData.isConsecutiveMatch)
        {
            PlayerDataManager.instance.playerData.showTypeConsecutiveCount++;
        }
        else
        {
            PlayerDataManager.instance.playerData.isConsecutiveMatch = false;
            PlayerDataManager.instance.playerData.showTypeConsecutiveCount = 1;
        }

        // happiness bonus for completing event.
        _promoInfo.promotion.PromoterHappiness += NegotiationDataManager.instance.CompleteShowPromoterHappinessBonus;
        
        // daily challenge.
        if (Math.Abs(_promoRating - 5) < 0.01f)
        {
            DailyChallengesDataManager.instance.ChallengePerfectPromo.ChallengeProgress++;
            SaveManager.instance.SaveDailyChallengesData((pp_success, pp_message) => {});
        }
        
        // save after event.
        PlayerDataManager.instance.playerData.eventsDoneToday.Add(_promoInfo.promotion);
        SaveManager.instance.SaveData((p_success, p_message) =>
        {
            SaveManager.instance.SaveBoostStoreData((pp_success, pp_message) => 
            {
                SaveManager.instance.SaveLeaderboardData((ppp_success, ppp_message) => { });
            });
        });

        if (_promoInfo.promotion.contractDaysLeft == 0)
        {
            _promoterFeedbackManager.Activate(_promoInfo.promotion);
            return;
        }

        CheckScheduledPromotionsAndGoHome();
    }
    
    private void CheckScheduledPromotionsAndGoHome()
    {
        if (!PromotionDataManager.instance.HasScheduledPromotionDates)
        {
            ShowNoPromotionsDialog();
            return;
        }
        
        goToHome?.Invoke();
    }

    private void ShowNoPromotionsDialog()
    {
        _noMoroPromotionsDialog.gameObject.SetActive(true);
    }

    public void OnNoPromotionsDialogNoClicked()
    {
        goToHome?.Invoke();
    }
    
    public void OnNoPromotionsDialogYesClicked()
    {
        goToWorld?.Invoke();
    }

    private void OnPromoterFeedbackNextButtonClicked()
    {
        _promoterFeedbackManager.Deactivate();
        CheckScheduledPromotionsAndGoHome();
    }
}
