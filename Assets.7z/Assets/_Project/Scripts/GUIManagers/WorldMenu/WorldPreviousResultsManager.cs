﻿using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WorldPreviousResultsManager : MonoBehaviour
{
	[SerializeField] private RectTransform resultsHolder;
	[SerializeField] private UIResultInfo resultInfoPrefab;

	[SerializeField] private TMP_Text titleText;
	[SerializeField] Image _promotionLogo = null;
	[SerializeField] TextMeshProUGUI _promotionPositionText = null;
	[SerializeField] Slider _happinessBar = null;
	[SerializeField] TextMeshProUGUI _happinessValue = null;
	[SerializeField] TextMeshProUGUI _winsCountText = null;
	[SerializeField] TextMeshProUGUI _lossCountText = null;

	[Header("Texts for Language")]
	[SerializeField] TextMeshProUGUI _happiness_title;
	[SerializeField] TextMeshProUGUI _wins_title;
	[SerializeField] TextMeshProUGUI _losses_title;

	private readonly List<UIResultInfo> _resultInfos = new List<UIResultInfo>();
	
	public void Activate(PromotionData promotionData)
	{
		gameObject.SetActive(true);

		titleText.text =  LanguageDataManager.instance.LangWorldText("PREVIOUS") + " " +
			promotionData.promotionInitials + " " + LanguageDataManager.instance.LangWorldText("RESULTS");
		_happiness_title.text = LanguageDataManager.instance.LangWorldText("happiness_title");
		_wins_title.text = LanguageDataManager.instance.LangWorldText("wins_title");
		_losses_title.text = LanguageDataManager.instance.LangWorldText("losses_title");

		_promotionLogo.sprite = promotionData.PromotionLogo;
		switch (promotionData.playerPosition)
		{
			case Enums.Position.OPENER:
				_promotionPositionText.text = LanguageDataManager.instance.LangWorldText("opener");
				break;

			case Enums.Position.LOWER:
				_promotionPositionText.text = LanguageDataManager.instance.LangWorldText("lower card");
				break;

			case Enums.Position.MID:
				_promotionPositionText.text = LanguageDataManager.instance.LangWorldText("mid card");
				break;

			case Enums.Position.UPPER:
				_promotionPositionText.text = LanguageDataManager.instance.LangWorldText("upper card");
				break;

			case Enums.Position.MAIN:
				_promotionPositionText.text = LanguageDataManager.instance.LangWorldText("main event");
				break;
		}
		_happinessBar.value = promotionData.PromoterHappiness;
		_happinessValue.text = $"{promotionData.PromoterHappiness}/100";
		_winsCountText.text = promotionData.matchWinCount.ToString();
		_lossCountText.text = promotionData.matchLossCount.ToString();

		Clear();
		SpawnItems(promotionData);
		
		LayoutRebuilder.ForceRebuildLayoutImmediate(transform as RectTransform);
	}

	public void Deactivate()
	{
		gameObject.SetActive(false);
	}

	private void Clear()
	{
		_resultInfos.ForEach(item => Destroy(item.gameObject));
		_resultInfos.Clear();
	}

	private void SpawnItems(PromotionData promotionData)
	{
		int nIndex = 0;
		var feuds = promotionData.GetShowResults();
		feuds.ForEach(result =>
		{
			var info = Instantiate(resultInfoPrefab, resultsHolder);
			if (info.Init(result, nIndex++) == true)
				_resultInfos.Add(info);
			else if (info.gameObject == true)
				GameObject.Destroy(info.gameObject);
		});
	}
}