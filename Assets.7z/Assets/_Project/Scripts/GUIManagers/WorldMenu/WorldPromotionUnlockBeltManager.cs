﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;

public class WorldPromotionUnlockBeltManager : LanguageCtrl
{
    public Action next;
    
    [SerializeField] GameObject _unlockScreen = null;
    [SerializeField] Image _logo = null;
    [SerializeField] TextMeshProUGUI _initials = null;

    [Header("Belt")]
    [SerializeField] Image _belt = null;
    [SerializeField] Sprite _defaultBelt = null;
    [SerializeField] GameObject _imageLoadingIcon = null;
    [SerializeField] private TMP_Text titleNameText;

    [Header("Animation")]
    [SerializeField] CanvasGroup _ribbonCanvasGroup = null;
    [SerializeField] CanvasGroup _promotionCanvasGroup = null;
    [SerializeField] CanvasGroup _titleCanvasGroup = null;
    [SerializeField] CanvasGroup _subtitleCanvasGroup = null;
    [SerializeField] CanvasGroup _beltCanvasGroup = null;
    [SerializeField] CanvasGroup _nextButtonCanvasGroup = null;
    [SerializeField] CanvasGroup _lightningCanvasGroup = null;
    [SerializeField] Animator _lightningAnimator = null;

    [Header("SFX")]
    [SerializeField] AudioClip _lightningClip = null;
    [SerializeField] [Range(0, 1)] float _lightningClipVolume = 1;

    [Header("Texts for Language")]
    [SerializeField] TextMeshProUGUI _congrat_title;
    [SerializeField] TextMeshProUGUI _youveunlock_title;
    [SerializeField] TextMeshProUGUI _next_btn;

    PromotionData _promotion;
    Coroutine _animation = null;
    private static readonly int DoLightning = Animator.StringToHash("DoLightning");

    public void Activate(PromotionData p_promotion, bool p_isMainTitle)
    {
        _promotion = p_promotion;

        titleNameText.text = p_isMainTitle ? LanguageDataManager.instance.LangWorldText("world title")
            : p_promotion.midTitleName.Replace(LanguageDataManager.instance.LangWorldText("champion_title"), LanguageDataManager.instance.LangWorldText("title"));
        
        PromotionBeltUpdated(_promotion, p_isMainTitle);
        
        if (p_promotion.PromotionLogo == null)
        {
            _logo.gameObject.SetActive(false);
            _initials.gameObject.SetActive(true);
            _initials.text = p_promotion.promotionInitials;
        }
        else
        {
            _logo.gameObject.SetActive(true);
            _initials.gameObject.SetActive(false);
            _logo.sprite = p_promotion.PromotionLogo;
        }

        _unlockScreen.SetActive(true);
        AnimationSetup();

        
    }

    public void Start()
    {
        LangSelect();
    }

    public override void LangSelect()
    {
        _congrat_title.text = LanguageDataManager.instance.LangWorldText("congrat_title");
        if (PlayerDataManager.instance.playerData._bPickLeaderboardReward == 1 && PlayerDataManager.instance.playerData._lastMyRanking == 1)
            _youveunlock_title.text = LanguageDataManager.instance.LangWorldText("youvewon_title");
        else
            _youveunlock_title.text = LanguageDataManager.instance.LangWorldText("youveunlock_title");
        _next_btn.text = LanguageDataManager.instance.LangWorldText("next_btn");
    }

    public void KUpdate()  
    { 
        if (gameObject.activeInHierarchy)  
        { 
            if (_animation == null)  
            { 
                _animation = StartCoroutine(DoAnimation()); 
            } 
        } 
    } 

    void PromotionBeltUpdated(PromotionData p_promotion, bool p_isMainTitle) 
    {
        _belt.gameObject.SetActive(true);
        _imageLoadingIcon.SetActive(false);

        var __belt = p_isMainTitle ? p_promotion.TitleBelt : p_promotion.MidTitleBelt;
        _belt.sprite = __belt == null ? _defaultBelt : __belt;
    }

    public void Deactivate()
    {
        _animation = null;
        _unlockScreen.SetActive(false);
    }

    public void NextButton()
    {
        next?.Invoke();
    }

    void AnimationSetup() 
    {
        _ribbonCanvasGroup.alpha = 0;
        _subtitleCanvasGroup.alpha = 0;
        _promotionCanvasGroup.alpha = 0;
        _promotionCanvasGroup.transform.localScale = Vector3.one;
        _titleCanvasGroup.alpha = 0;
        _titleCanvasGroup.transform.localScale = Vector3.one;
        _beltCanvasGroup.alpha = 0;
        _lightningCanvasGroup.alpha = 0;
        _nextButtonCanvasGroup.alpha = 0;
        _nextButtonCanvasGroup.interactable = false;
    }

    IEnumerator DoAnimation() 
    {
        float __timer;

        __timer = 0;
        while(__timer < 0.3f) 
        {
            yield return null;
            __timer += Time.deltaTime;
            _ribbonCanvasGroup.alpha = Mathf.Lerp(0, 1, __timer / 0.3f);
        }

        __timer = 0;
        while(__timer < 0.2f) 
        {
            yield return null;
            __timer += Time.deltaTime;
            _subtitleCanvasGroup.alpha = Mathf.Lerp(0, 1, __timer / 0.2f);
        }

        bool __lightning = false;
        __timer = 0;
        while(__timer < 0.4f) 
        {
            yield return null;
            __timer += Time.deltaTime;
            
            _titleCanvasGroup.alpha = Mathf.Lerp(0, 1, __timer / 0.2f);
            _promotionCanvasGroup.alpha = Mathf.Lerp(0, 1, __timer / 0.2f);
            if (__timer < 0.2f) 
            {
                _titleCanvasGroup.transform.localScale = Vector3.one * Mathf.Lerp(1, 1.1f, __timer / 0.2f);
                _promotionCanvasGroup.transform.localScale = Vector3.one * Mathf.Lerp(1, 1.1f, __timer / 0.2f);
            }
            else
            {
                _titleCanvasGroup.transform.localScale = Vector3.one * Mathf.Lerp(1.1f, 1, (__timer - 0.2f) / 0.2f);
                _promotionCanvasGroup.transform.localScale = Vector3.one * Mathf.Lerp(1.1f, 1, (__timer - 0.2f) / 0.2f);
            }

            _beltCanvasGroup.alpha = Mathf.Lerp(0, 1, __timer / 0.3f);
            if (__timer > 0.3f) 
            {
                if (!__lightning) 
                {
                    __lightning = true;
                    _lightningCanvasGroup.alpha = 1;
                    _lightningAnimator.SetTrigger(DoLightning);
                    SFXPlayerManager.instance.PlayOneShot(_lightningClip, _lightningClipVolume);
                }
            }
        }

        _nextButtonCanvasGroup.interactable = true;
        __timer = 0;
        while(__timer < 0.3f) 
        {
            yield return null;
            __timer += Time.deltaTime;
            _nextButtonCanvasGroup.alpha = Mathf.Lerp(0, 1, __timer / 0.3f);
        }
    }
}
