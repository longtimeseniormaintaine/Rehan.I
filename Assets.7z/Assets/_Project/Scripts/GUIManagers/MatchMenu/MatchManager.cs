﻿using UnityEngine;
using System;
using TMPro;

public class MatchManager : LanguageCtrl
{
    public Action goToHome;
    public Action goToWorld;
    
    [Header("Screens")]
    public GameObject matchMenu;
    public MatchCommentaryManager commentaryManager;
    public MatchRatingManager ratingManager;
    [SerializeField] MatchWonTitleBeltManager _wonTitleBeltManager = null;
    [SerializeField] MatchFeedbackManager _feedbackManager = null;
    [SerializeField] MatchStatsManager _statsManager = null;
    [SerializeField] MatchLevelUpManager _levelUpManager = null;
    [SerializeField] MatchProgressRewardManager _progressRewardManager = null;
    [SerializeField] MatchUnlockPromotionManager _unlockPromotionManager = null;
    [SerializeField] MatchPromoterFeedbackManager _promoterFeedbackManager = null;
    [SerializeField] GameObject _noMoroPromotionsDialog = null;

    [Header("Headlines")]
    [SerializeField] UIHeadlinePlayer _playerHeadline = null;
    [SerializeField] UIHeadlineDate _dateHeadline = null;

    [Header("Data")]
    public MatchInfo matchInfo;
    public PlayerData playerData;

    [Header("Texts for Language")]
    [SerializeField] TextMeshProUGUI _getmorebooking_title;
    [SerializeField] TextMeshProUGUI _getmorebooking_description;
    [SerializeField] TextMeshProUGUI _yes_btn;
    [SerializeField] TextMeshProUGUI _no_btn;

    float _matchRating;

    public void Kinitialize()
    {
        commentaryManager.matchOver += MatchResult;
        ratingManager.retryMatch += RetryMatch;
        ratingManager.proceed += ProceedFromRating;
        _wonTitleBeltManager.next += NextFromBelt;
        _feedbackManager.next += NextFromFeedback;
        _statsManager.next += NextFromStats;
        _levelUpManager.next += NextFromLevelUp;
        _progressRewardManager.next += NextFromProgressReward;
        _unlockPromotionManager.next += NextFromUnlockPromotion;
        _promoterFeedbackManager.onNextButtonClicked += OnPromoterFeedbackNextButtonClicked;

        commentaryManager.KInitialize();
        ratingManager.KInitialize();

        
    }

    public void Start()
    {
        LangSelect();
    }

    public void KUpdate()
    {
        commentaryManager.KUpdate();
        _statsManager.KUpdate();
        _feedbackManager.KUpdate();
        _wonTitleBeltManager.KUpdate();
        _unlockPromotionManager.KUpdate();
        _levelUpManager.KUpdate();
    }

    public override void LangSelect()
    {
        _getmorebooking_title.text = LanguageDataManager.instance.LangMatchText("getmorebooking_title");
        _getmorebooking_description.text = LanguageDataManager.instance.LangMatchText("getmorebooking_description");
        _yes_btn.text = LanguageDataManager.instance.LangMatchText("yes_btn");
        _no_btn.text = LanguageDataManager.instance.LangMatchText("no_btn");
    }

    public void KOnEnable()
    {
        //reset screens.
        commentaryManager.Activate(matchInfo);
        ratingManager.Deactivate();
        _wonTitleBeltManager.Deactivate();
        _feedbackManager.Deactivate();
        _statsManager.Deactivate();
        _levelUpManager.Deactivate();
        _progressRewardManager.Deactivate();
        _unlockPromotionManager.Deactivate();
        _promoterFeedbackManager.Deactivate();
        _noMoroPromotionsDialog.gameObject.SetActive(false);

        _playerHeadline.UpdateContent();
        _dateHeadline.UpdateContent();
        if (matchInfo.opponent.isChampion || matchInfo.promotion.playerIsChampion || matchInfo.opponent.isMidTitleChampion || matchInfo.promotion.playerIsMidTitleChampion) 
        {
            _playerHeadline.SetChampion();
        }
        else
        {
            _playerHeadline.SetNormal();
        }

        matchMenu.SetActive(true);
    }

    public void KOnDisable()
    {
        ratingManager.ResetRefereeCost();
        matchMenu.SetActive(false);
    }

    void MatchResult(float p_rating)
    {
        _matchRating = p_rating;
        
        commentaryManager.Deactivate();
        ratingManager.Activate(p_rating, matchInfo.promotion.contractPosition, matchInfo.promotion.playerIsChampion);
    }

    void RetryMatch()
    {
        ratingManager.Deactivate();
        commentaryManager.Activate(matchInfo);
    }

    void ProceedFromRating()
    {
        ratingManager.Deactivate();

        matchInfo.promotion.AddShowRating(_matchRating);
        int nLevel = 0;
        if (matchInfo.opponent.isChampion == true || matchInfo.promotion.playerIsChampion == true)
            nLevel = 1;
        if (matchInfo.opponent.isMidTitleChampion == true || matchInfo.promotion.playerIsMidTitleChampion == true)
            nLevel = 2;

        matchInfo.promotion.AddShowResult(_matchRating, matchInfo.opponent.wrestlerData, DateManager.instance.GetDate(), matchInfo.promotion.eventName, (int)Enums.PromotionType.MATCH, matchInfo.isGoingToWin, nLevel, matchInfo.isDQMatch | matchInfo.isCountOutMatch);
        
        // The wrestler can't lose championship title if in a DQ or count-out match.
        if (!matchInfo.isDQMatch && !matchInfo.isCountOutMatch)
        {
            // Case where you win the belt.
            if (matchInfo.isGoingToWin)
            {
                if (matchInfo.opponent.isChampion)
                {
                    matchInfo.promotion.playerIsChampion = true;
                    matchInfo.opponent.isChampion = false;
                    PlayerDataManager.instance.playerData.AddChampionship(matchInfo.promotion);
                    _wonTitleBeltManager.Activate(matchInfo.promotion, true);
                    return;
                }
                
                if (matchInfo.opponent.isMidTitleChampion)
                {
                    matchInfo.promotion.playerIsMidTitleChampion = true;
                    matchInfo.opponent.isMidTitleChampion = false;
                    PlayerDataManager.instance.playerData.AddMidTitleChampionship(matchInfo.promotion);
                    _wonTitleBeltManager.Activate(matchInfo.promotion, false);
                    return;
                }
            }

            // Case where you lose the belt.
            if (!matchInfo.isGoingToWin)
            {
                if (matchInfo.promotion.playerIsChampion)
                {
                    matchInfo.promotion.playerIsChampion = false;
                    matchInfo.opponent.isChampion = true;
                }
                
                if (matchInfo.promotion.playerIsMidTitleChampion)
                {
                    matchInfo.promotion.playerIsMidTitleChampion = false;
                    matchInfo.opponent.isMidTitleChampion = true;
                }
            }
        }
        
        _feedbackManager.Activate(_matchRating, matchInfo);
    }

    void NextFromBelt()
    {
        _wonTitleBeltManager.Deactivate();
        _feedbackManager.Activate(_matchRating, matchInfo);
    }

    void NextFromFeedback()
    {
        _feedbackManager.Deactivate();
        _statsManager.Activate(_matchRating, matchInfo);
    }

    void NextFromStats()
    {
        _statsManager.Deactivate();

        // Register match in promotion;
        if (matchInfo.isGoingToWin)
        {
            matchInfo.promotion.matchWinCount++;
        }
        else
        {
            matchInfo.promotion.matchLossCount++;
        }
        matchInfo.promotion.AddMatch(_matchRating, matchInfo.opponent.wrestlerData, DateManager.instance.GetDate(), matchInfo.promotion.eventName, matchInfo.isGoingToWin);
        
        if (playerData.hasLeveledUp)
        {
            _levelUpManager.Activate(playerData);
        }
        else 
        {
            ExitEvent();
        }
    }

    void NextFromLevelUp()
    {
        Debug.Log("========");
        _levelUpManager.Deactivate();
        
        if (PromotionDataManager.instance.CheckIfUnlockedNewPromotion())
        {
            _unlockPromotionManager.Activate();
        }
        else
        {
            if (LevelProgressionDataManager.instance.GotPerks)
            {
                _progressRewardManager.Activate();
            }
            else
            {
                ExitEvent();
            }
        }
    }

    void NextFromProgressReward() 
    {
        _progressRewardManager.Deactivate();
        _playerHeadline.UpdateContent();
        ExitEvent();
    }

    void NextFromUnlockPromotion()
    {   
        _unlockPromotionManager.Deactivate();

        if (LevelProgressionDataManager.instance.GotPerks)
        {
            _progressRewardManager.Activate();
        }
        else
        {
            ExitEvent();
        }
    }

    void ExitEvent()
    {
        // Match payment.
        playerData.money += matchInfo.promotion.contractPayPerMatch;
        matchInfo.promotion.contractDaysLeft--;
        SFXPlayerManager.instance.PlayMoneySFX();
        
        // match or promo repetition.
        if (PlayerDataManager.instance.playerData.isConsecutiveMatch)
        {
            PlayerDataManager.instance.playerData.showTypeConsecutiveCount++;
        }
        else
        {
            PlayerDataManager.instance.playerData.isConsecutiveMatch = true;
            PlayerDataManager.instance.playerData.showTypeConsecutiveCount = 1;
        }

        // new promotion match conditions.
        if (matchInfo.promotion.isFirstMatch) 
        {
            matchInfo.promotion.isFirstMatch = false;
        }
        if (matchInfo.promotion.isInitialMatchStreak) 
        {
            if (_matchRating < 4) 
            {
                matchInfo.promotion.isInitialMatchStreak = false;
            }
        }
        
        // happiness bonus for completing event.
        matchInfo.promotion.PromoterHappiness += NegotiationDataManager.instance.CompleteShowPromoterHappinessBonus;
        
        // daily challenge.
        if (matchInfo.isGoingToWin)
        {
            DailyChallengesDataManager.instance.ChallengeWinMatch.ChallengeProgress++;
            SaveManager.instance.SaveDailyChallengesData((pp_success, pp_message) => {});
        }
        
        // save after event.
        PlayerDataManager.instance.playerData.eventsDoneToday.Add(matchInfo.promotion);
        SaveManager.instance.SaveData((p_success, p_message) =>
        {
            SaveManager.instance.SaveBoostStoreData((pp_success, pp_message) => 
            {
                SaveManager.instance.SaveLeaderboardData((ppp_success, ppp_message) => { });
            });
        });

        if (matchInfo.promotion.contractDaysLeft == 0)
        {
            _promoterFeedbackManager.Activate(matchInfo.promotion);
            return;
        }

        CheckScheduledPromotionsAndGoHome();
    }

    private void CheckScheduledPromotionsAndGoHome()
    {
        if (!PromotionDataManager.instance.HasScheduledPromotionDates)
        {
            ShowNoPromotionsDialog();
            return;
        }
        
        goToHome?.Invoke();
    }

    private void ShowNoPromotionsDialog()
    {
        _noMoroPromotionsDialog.gameObject.SetActive(true);
    }

    public void OnNoPromotionsDialogNoClicked()
    {
        goToHome?.Invoke();
    }
    
    public void OnNoPromotionsDialogYesClicked()
    {
        goToWorld?.Invoke();
    }

    private void OnPromoterFeedbackNextButtonClicked()
    {
        _promoterFeedbackManager.Deactivate();
        CheckScheduledPromotionsAndGoHome();
    }
}
