﻿using UnityEngine;
using System;
using Random = UnityEngine.Random;

public class DateManager : MonoBehaviour
{
    public static DateManager instance;

    public Action dateChanged;
    public Action incidentReset;

    public DateTime incidentNextDate;
    public DateTime incidentLastDate;

    DateTime _date = new DateTime();
    DateTime _initialDate = new DateTime(2020, 10, 11);

    void Awake() {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Debug.LogWarning("Multiple DateManager!");
            Destroy(gameObject);
        }

        _date = _initialDate;
        incidentNextDate = _initialDate;
    }

    public void SetDateFromTotalDays(int p_days)
    {
        _date = _initialDate.AddDays(p_days);

        dateChanged?.Invoke();
    }

    public DateTime GetDate()
    {
        return _date;
    }

    public DateTime GetDateFromTotalDays(int p_days)
    {
        DateTime __date = _initialDate.AddDays(p_days);
        return __date;
    }

    public int GetTotalDays()
    {
        TimeSpan __timespan = _date - _initialDate;
        return __timespan.Days;
    }

    public int GetTotalDaysFromDate(DateTime p_date)
    {
        TimeSpan __timespan = p_date - _initialDate;
        return __timespan.Days;
    }

    public int GetWeek()
    {
        return GetTotalDays() / 7 + 1;
    }

    public DateTime GetWeekStartDay(int p_week)
    {
        DateTime __weekStartDay = _initialDate.AddDays((p_week - 1) * 7);
        return __weekStartDay;
    }

    public DateTime GetWeekEndDay(int p_week)
    {
        DateTime __weekEndDay = _initialDate.AddDays((p_week) * 7 - 1);
        return __weekEndDay;
    }

    public Enums.WeekDay GetWeekday()
    {
        return (Enums.WeekDay)_date.DayOfWeek;
    }

    public bool IsNewWeek()
    {
        return GetTotalDays() % 7 == 0;
    }
    
    public void NextDay()
    {
        if (HasIncidentToday())
        {
            SetIncidentNextDate();
        }
        
        DateTime __previousDay = _date.AddDays(0);
        _date = _date.AddDays(1);
        if (__previousDay.Month != _date.Month) 
        {
            PromotionDataManager.instance.ModifyPromotersHappinessWithoutContract(NegotiationDataManager.instance.MonthlyPromoterHappinessBonus, true);
        }

        dateChanged?.Invoke();
    }

    public void ResetDate()
    {
        _date = _initialDate;
    }

    public void ResetIncidentDate() 
    {
        incidentNextDate = _initialDate;
        incidentLastDate = new DateTime();
        incidentReset?.Invoke();
    }

    public bool HasIncidentToday()
    {
        if (_date == incidentNextDate)
        {
            return true;
        }
        return false;
    }

    public void SetIncidentNextDate()
    {
        incidentLastDate = incidentNextDate.AddDays(0);

        int __diff = GetTotalDaysFromDate(incidentNextDate) % 7;
        if (__diff > 3)
        {
            __diff = 7 - __diff;
        }
        else
        {
            __diff = -__diff;
        }
        int __random = Random.Range(-1, 2);
        incidentNextDate = incidentNextDate.AddDays(7 + __diff + __random);
    }
}
