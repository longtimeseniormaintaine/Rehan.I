﻿using System.Collections;
using UnityEngine;
using Firebase.Database;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

public class SaveManager : MonoBehaviour
{
    const string USERS_PATH = "Users/";
    const string USERS_PLAYER_DATA_PATH = "/PlayerData";
    const string USERS_SCHEDULE_PATH = "/PlayerSchedule";
    const string USERS_PROMOTION_DATA_PATH = "/PromotionData";
    const string USERS_BOOSTS_STORE_DATA_PATH = "/BoostsStoreData";
    const string USERS_RESET_DATA_PATH = "/ResetData";
    const string USERS_DAILY_CHALLENGES_DATA_PATH = "/DailyChallengesData";
    const string USERS_SHOW_DATA_PATH = "/ShowData";
    const string USERS_ERASE_DATA_PATH = "/EraseData";

    const string LEADERBOARD_PATH = "Leaderboard/";



    public static SaveManager instance;

    [SerializeField] float _timeoutTime = 60;

    bool _isInitialized = false;
    FirebaseDatabase _database;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Debug.LogWarning("Multiple SaveManager!");
            Destroy(gameObject);
        }
    }

    void Start()
    {
        FirebaseInit.instance.initialized += FirebaseInitialized;
    }

    void FirebaseInitialized(bool p_success)
    {
        _database = FirebaseDatabase.DefaultInstance;
        _database.SetPersistenceEnabled(false);
        _isInitialized = true;
    }


    #region Public calls

    
    public void SaveAccountData(Action<bool, string> p_callback)
    {
        SaveData((p_success, p_message) =>
        {
            SaveBoostStoreData((pp_success, pp_message) =>
            {
                SaveDailyChallengesData((ppp_success, ppp_message) =>
                {
                    SaveResetData((pppp_success, pppp_message) =>
                    {
                        SaveShowData((ppppp_success, ppppp_message) =>
                        {
                            SaveLeaderboardData((pppppp_success, pppppp_message) =>
                            {
                                Debug.Log("[Settings] Changed to mail account");
                                p_callback(pppppp_success, pppppp_message);
                            });
                        });
                    });
                });
            });
        });
    }

    public void LoadAccountData(Action<bool, string> p_callback)
    {
        DownLoadAccountData((dp_success, dp_message) =>
        {
            if (dp_success == false)
                p_callback(false, dp_message);
            else
            {
                LoadData((p_success, p_message) =>
                {
                    LoadBoostStoreData((pp_success, pp_message) =>
                    {
                        LoadDailyChallengesData((ppp_success, ppp_message) =>
                        {
                            LoadResetData((pppp_success, pppp_message) =>
                            {
                                LoadShowData((ppppp_success, ppppp_message) =>
                                {
                                    LoadLeaderboardData((pppppp_success, pppppp_message) =>
                                    {
                                        LoadRankingLeaderboard((ppppppp_success, ppppppp_message) =>
                                        {
                                            LoadRankingLastLeaderboard((pppppppp_success, pppppppp_message) =>
                                            {
                                                Debug.Log("[Settings] Changed to mail account");
                                                p_callback(pppppppp_success, pppppppp_message);
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            }
        });
    }

    #endregion


    public void DownLoadAccountData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoDownLoadAccountData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }


    public void LoadData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoLoadData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }

    public void SaveData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoSaveData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }


    public void LoadBoostStoreData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoLoadBoostStoreData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }
    
    public void SaveBoostStoreData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoSaveBoostStoreData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }


    public void LoadDailyChallengesData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoLoadDailyChallengesData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }

    public void SaveDailyChallengesData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoSaveDailyChallengesData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }


    public void LoadResetData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoLoadResetData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }

    public void SaveResetData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoSaveResetData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }
    

    public void LoadShowData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoLoadShowData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }

    public void SaveShowData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoSaveShowData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }


    public void LoadLeaderboardData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoLoadLeaderboardData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }

    public void SaveLeaderboardData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoSaveLeaderboardData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }


    public void EraseData(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoEraseData(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }




    IEnumerator DoDownLoadAccountData(Action<bool, string> p_callback)
    {
        // Load special user data.
        if (InternetConnectionManager.instance._connected == false)
        {
            p_callback(false, "Connection Failed");
            yield break;
        }


        // Erase game prefs.
        PlayerPrefs.SetInt("CHECK" + USERS_PLAYER_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_SCHEDULE_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_PROMOTION_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_BOOSTS_STORE_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_RESET_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_DAILY_CHALLENGES_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_SHOW_DATA_PATH, 0);

        PlayerPrefs.DeleteKey("DATA" + USERS_PLAYER_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_SCHEDULE_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_PROMOTION_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_BOOSTS_STORE_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_RESET_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_DAILY_CHALLENGES_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_SHOW_DATA_PATH);


        p_callback(true, "Data downloaded successfully");
        yield return null;
    }

    IEnumerator DoLoadData(Action<bool, string> p_callback)
    {
        string strLoadData = string.Empty;
        string __loadPath;
        Task<DataSnapshot> __checkTask;
        float __timer;


        PlayerSaveJSONData __loadPlayerData = null;
        ScheduleSaveJSONData __loadScheduleData = null;
        PromotionSaveJSONData __loadPromotionData = null;


        // Load special user data.
        if (DeveloperDatabaseManager.instance._useSpecialUserInfo == true)
        {
            strLoadData = LanguageDataManager.instance.GetSpecialUserData(USERS_PLAYER_DATA_PATH.Replace("/", ""));
            __loadPlayerData = JsonUtility.FromJson<PlayerSaveJSONData>(strLoadData);

            strLoadData = LanguageDataManager.instance.GetSpecialUserData(USERS_SCHEDULE_PATH.Replace("/", ""));
            __loadScheduleData = JsonUtility.FromJson<ScheduleSaveJSONData>(strLoadData);

            strLoadData = LanguageDataManager.instance.GetSpecialUserData(USERS_PROMOTION_DATA_PATH.Replace("/", ""));
            __loadPromotionData = JsonUtility.FromJson<PromotionSaveJSONData>(strLoadData);


            if (__loadPlayerData != null)
            {
                __loadPlayerData.GetData(PlayerDataManager.instance.playerData);
            }
            else
            {
                PlayerDataManager.instance.Reset();
                WardrobeDataManager.instance.ResetAllWardrobeData();
            }

            if (__loadScheduleData != null)
            {
                __loadScheduleData.GetSchedule(PlayerDataManager.instance.playerData);
            }
            else
            {
                PlayerDataManager.instance.playerData.scheduleData = new ScheduleData();
            }

            __loadPromotionData?.GetData();

            p_callback(true, "Data loaded successfully");
            yield break;
        }


        // Load player data.
        if (PlayerPrefs.HasKey("DATA" + USERS_PLAYER_DATA_PATH))
        {
            strLoadData = PlayerPrefs.GetString("DATA" + USERS_PLAYER_DATA_PATH);
            __loadPlayerData = JsonUtility.FromJson<PlayerSaveJSONData>(strLoadData);
        }
        else if (DeveloperDatabaseManager.instance._useFirebaseLoad == false)
        {
            p_callback(false, "Data do not exist");
            yield break;
        }
        else
        {
            __loadPath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_PLAYER_DATA_PATH}";
            __checkTask = _database.GetReference(__loadPath).GetValueAsync();

            __timer = 0;
            while (!__checkTask.IsCompleted)
            {
                yield return null;
                __timer += Time.deltaTime;
                if (__timer >= _timeoutTime)
                {
                    break;
                }
            }

            if (__checkTask.IsCompleted)
            {
                if (__checkTask.Result.Exists)
                {
                    __loadPlayerData = JsonUtility.FromJson<PlayerSaveJSONData>(__checkTask.Result.GetRawJsonValue());
                }
                else
                {
                    p_callback(false, "Data do not exist");
                    yield break;
                }
            }
            else
            {
                InternetConnectionManager.instance._connected = false;
                p_callback(false, "Load data timeout");
                yield break;
            }
        }


        // Load schedule data.
        if (PlayerPrefs.HasKey("DATA" + USERS_SCHEDULE_PATH))
        {
            strLoadData = PlayerPrefs.GetString("DATA" + USERS_SCHEDULE_PATH);
            __loadScheduleData = JsonUtility.FromJson<ScheduleSaveJSONData>(strLoadData);
        }
        else
        {
            __loadPath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_SCHEDULE_PATH}";
            __checkTask = _database.GetReference(__loadPath).GetValueAsync();

            __timer = 0;
            while (!__checkTask.IsCompleted)
            {
                yield return null;
                __timer += Time.deltaTime;
                if (__timer >= _timeoutTime)
                {
                    break;
                }
            }

            if (__checkTask.IsCompleted)
            {
                if (__checkTask.Result.Exists)
                {
                    __loadScheduleData = JsonUtility.FromJson<ScheduleSaveJSONData>(__checkTask.Result.GetRawJsonValue());
                }
                else
                {
                    Debug.Log("Data do not exist");
                }
            }
            else
            {
                InternetConnectionManager.instance._connected = false;
                Debug.Log("Load data timeout");
            }
        }


        // Load promotion data.
        if (PlayerPrefs.HasKey("DATA" + USERS_PROMOTION_DATA_PATH))
        {
            strLoadData = PlayerPrefs.GetString("DATA" + USERS_PROMOTION_DATA_PATH);
            __loadPromotionData = JsonUtility.FromJson<PromotionSaveJSONData>(strLoadData);
        }
        else
        {
            __loadPath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_PROMOTION_DATA_PATH}";
            __checkTask = _database.GetReference(__loadPath).GetValueAsync();

            __timer = 0;
            while (!__checkTask.IsCompleted)
            {
                yield return null;
                __timer += Time.deltaTime;
                if (__timer >= _timeoutTime)
                {
                    break;
                }
            }

            if (__checkTask.IsCompleted)
            {
                if (__checkTask.Result.Exists)
                {
                    __loadPromotionData = JsonUtility.FromJson<PromotionSaveJSONData>(__checkTask.Result.GetRawJsonValue());
                }
                else
                {
                    Debug.Log("Data do not exist");
                }
            }
            else
            {
                InternetConnectionManager.instance._connected = false;
                Debug.Log("Load data timeout");
            }
        }


        if (__loadPlayerData != null)
        {
            __loadPlayerData.GetData(PlayerDataManager.instance.playerData);
        }
        else
        {
            PlayerDataManager.instance.Reset();
            WardrobeDataManager.instance.ResetAllWardrobeData();
        }

        if (__loadScheduleData != null)
        {
            __loadScheduleData.GetSchedule(PlayerDataManager.instance.playerData);
        }
        else
        {
            PlayerDataManager.instance.playerData.scheduleData = new ScheduleData();
        }

        __loadPromotionData?.GetData();

        p_callback(true, "Data loaded successfully");
        yield return null;
    }

    IEnumerator DoSaveData(Action<bool, string> p_callback)
    {
        PlayerSaveJSONData __savePlayerData = new PlayerSaveJSONData();
        ScheduleSaveJSONData __saveScheduleData = new ScheduleSaveJSONData();
        PromotionSaveJSONData __savePromotionData = new PromotionSaveJSONData();


        // Pass all data to save here.
        __savePlayerData.SetData(PlayerDataManager.instance.playerData);
        __saveScheduleData.SetSchedule(PlayerDataManager.instance.playerData);
        __savePromotionData.SetData();


        // Save player data.
        PlayerPrefs.SetString("DATA" + USERS_PLAYER_DATA_PATH, JsonUtility.ToJson(__savePlayerData));
        PlayerPrefs.SetInt("CHECK" + USERS_PLAYER_DATA_PATH, 1);


        // Save schedule data.
        PlayerPrefs.SetString("DATA" + USERS_SCHEDULE_PATH, JsonUtility.ToJson(__saveScheduleData));
        PlayerPrefs.SetInt("CHECK" + USERS_SCHEDULE_PATH, 1);


        // Save promotion data.
        PlayerPrefs.SetString("DATA" + USERS_PROMOTION_DATA_PATH, JsonUtility.ToJson(__savePromotionData));
        PlayerPrefs.SetInt("CHECK" + USERS_PROMOTION_DATA_PATH, 1);


        if (InternetConnectionManager.instance._connected)
            StartCoroutine(cloudDoSaveData(p_callback));
        else
            p_callback(true, "Data saved successfully");

        yield return null;
    }

    IEnumerator cloudDoSaveData(Action<bool, string> p_callback)
    {
        string __savePath;
        Task __checkTask;
        float __timer;


        PlayerSaveJSONData __savePlayerData = new PlayerSaveJSONData();
        ScheduleSaveJSONData __saveScheduleData = new ScheduleSaveJSONData();
        PromotionSaveJSONData __savePromotionData = new PromotionSaveJSONData();


        // Pass all data to save here.
        __savePlayerData.SetData(PlayerDataManager.instance.playerData);
        __saveScheduleData.SetSchedule(PlayerDataManager.instance.playerData);
        __savePromotionData.SetData();


        // Save player data.
        __savePath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_PLAYER_DATA_PATH}";
        __checkTask = _database.GetReference(__savePath).SetRawJsonValueAsync(JsonUtility.ToJson(__savePlayerData));

        __timer = 0;
        while (!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Save data timeout");
            yield break;
        }


        // Save schedule data.
        __savePath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_SCHEDULE_PATH}";
        __checkTask = _database.GetReference(__savePath).SetRawJsonValueAsync(JsonUtility.ToJson(__saveScheduleData));

        __timer = 0;
        while (!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Save data timeout");
            yield break;
        }


        // Save promotion data.
        __savePath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_PROMOTION_DATA_PATH}";
        __checkTask = _database.GetReference(__savePath).SetRawJsonValueAsync(JsonUtility.ToJson(__savePromotionData));

        __timer = 0;
        while (!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Save data timeout");
            yield break;
        }


        checkDoSaveData();
        p_callback(true, "Data saved successfully");
        yield return null;
    }

    void checkDoSaveData()
    {
        // Save player data.
        PlayerPrefs.SetInt("CHECK" + USERS_PLAYER_DATA_PATH, 0);


        // Save schedule data.
        PlayerPrefs.SetInt("CHECK" + USERS_SCHEDULE_PATH, 0);


        // Save promotion data.
        PlayerPrefs.SetInt("CHECK" + USERS_PROMOTION_DATA_PATH, 0);
    }


    IEnumerator DoLoadBoostStoreData(Action<bool, string> p_callback)
    {
        string strLoadData = string.Empty;
        string __loadPath;
        Task<DataSnapshot> __checkTask;
        float __timer;


        BoostsStoreSaveJSONData __loadedData = null;


        // Load special user data.
        if (DeveloperDatabaseManager.instance._useSpecialUserInfo == true)
        {
            strLoadData = LanguageDataManager.instance.GetSpecialUserData(USERS_BOOSTS_STORE_DATA_PATH.Replace("/", ""));
            __loadedData = JsonUtility.FromJson<BoostsStoreSaveJSONData>(strLoadData);


            if (__loadedData != null)
                ShopBoostsDataManager.instance.GetLoadedData(__loadedData);
            else
            {
                p_callback(false, "Data loaded failed");
                yield break;
            }

            p_callback(true, "Data loaded successfully");
            yield break;
        }


        // Load boost store data.
        if (PlayerPrefs.HasKey("DATA" + USERS_BOOSTS_STORE_DATA_PATH))
        {
            strLoadData = PlayerPrefs.GetString("DATA" + USERS_BOOSTS_STORE_DATA_PATH);
            __loadedData = JsonUtility.FromJson<BoostsStoreSaveJSONData>(strLoadData);
        }
        else
        {
            __loadPath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_BOOSTS_STORE_DATA_PATH}";
            __checkTask = _database.GetReference(__loadPath).GetValueAsync();

            __timer = 0;
            while (!__checkTask.IsCompleted)
            {
                yield return null;
                __timer += Time.deltaTime;
                if (__timer >= _timeoutTime)
                {
                    break;
                }
            }

            if (__checkTask.IsCompleted)
            {
                if (__checkTask.Result.Exists)
                {
                    __loadedData = JsonUtility.FromJson<BoostsStoreSaveJSONData>(__checkTask.Result.GetRawJsonValue());
                }
                else
                {
                    Debug.Log("Data do not exist");
                }
            }
            else
            {
                InternetConnectionManager.instance._connected = false;
                Debug.Log("Load data timeout");
            }
        }


        if (__loadedData != null)
            ShopBoostsDataManager.instance.GetLoadedData(__loadedData);
        else
        {
            p_callback(false, "Data loaded failed");
            yield break;
        }


        p_callback(true, "Data loaded successfully");
        yield return null;
    }

    IEnumerator DoSaveBoostStoreData(Action<bool, string> p_callback)
    {
        BoostsStoreSaveJSONData __saveData = new BoostsStoreSaveJSONData();


        // Pass all data to save here.
        __saveData = ShopBoostsDataManager.instance.SetSaveData();


        // Save boost store data.
        PlayerPrefs.SetString("DATA" + USERS_BOOSTS_STORE_DATA_PATH, JsonUtility.ToJson(__saveData));
        PlayerPrefs.SetInt("CHECK" + USERS_BOOSTS_STORE_DATA_PATH, 1);


        if (InternetConnectionManager.instance._connected)
            StartCoroutine(cloudDoSaveBoostStoreData(p_callback));
        else
            p_callback(true, "Data saved successfully");

        yield return null;
    }

    IEnumerator cloudDoSaveBoostStoreData(Action<bool, string> p_callback)
    {
        string __savePath;
        Task __checkTask;
        float __timer;


        BoostsStoreSaveJSONData __saveData = new BoostsStoreSaveJSONData();


        // Pass all data to save here.
        __saveData = ShopBoostsDataManager.instance.SetSaveData();


        // Save boost store data.
        __savePath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_BOOSTS_STORE_DATA_PATH}";
        __checkTask = _database.GetReference(__savePath).SetRawJsonValueAsync(JsonUtility.ToJson(__saveData));

        __timer = 0;
        while(!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Save data timeout");
            yield break;
        }


        checkDoSaveBoostStoreData();
        p_callback(true, "Data saved successfully");
        yield return null;
    }

    void checkDoSaveBoostStoreData()
    {
        // Save boost store data.
        PlayerPrefs.SetInt("CHECK" + USERS_BOOSTS_STORE_DATA_PATH, 0);
    }


    IEnumerator DoLoadDailyChallengesData(Action<bool, string> p_callback)
    {
        string strLoadData = string.Empty;
        string __loadPath;
        Task<DataSnapshot> __checkTask;
        float __timer;


        DailyChallengeJSONData __loadedData = null;


        // Load special user data.
        if (DeveloperDatabaseManager.instance._useSpecialUserInfo == true)
        {
            strLoadData = LanguageDataManager.instance.GetSpecialUserData(USERS_DAILY_CHALLENGES_DATA_PATH.Replace("/", ""));
            __loadedData = JsonUtility.FromJson<DailyChallengeJSONData>(strLoadData);


            if (__loadedData != null)
                DailyChallengesDataManager.instance.GetLoadedData(__loadedData);
            else
            {
                DailyChallengesDataManager.instance.SetInitialData();
                p_callback(false, "Data loaded failed");
                yield break;
            }

            p_callback(true, "Data loaded successfully");
            yield break;
        }


        // Load challenge data.
        if (PlayerPrefs.HasKey("DATA" + USERS_DAILY_CHALLENGES_DATA_PATH))
        {
            strLoadData = PlayerPrefs.GetString("DATA" + USERS_DAILY_CHALLENGES_DATA_PATH);
            __loadedData = JsonUtility.FromJson<DailyChallengeJSONData>(strLoadData);
        }
        else
        {
            __loadPath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_DAILY_CHALLENGES_DATA_PATH}";
            __checkTask = _database.GetReference(__loadPath).GetValueAsync();

            __timer = 0;
            while (!__checkTask.IsCompleted)
            {
                yield return null;
                __timer += Time.deltaTime;
                if (__timer >= _timeoutTime)
                {
                    break;
                }
            }

            if (__checkTask.IsCompleted)
            {
                if (__checkTask.Result.Exists)
                {
                    __loadedData = JsonUtility.FromJson<DailyChallengeJSONData>(__checkTask.Result.GetRawJsonValue());
                }
                else
                {
                    Debug.Log("Data do not exist");
                }
            }
            else
            {
                InternetConnectionManager.instance._connected = false;
                Debug.Log("Load data timeout");
            }
        }


        if (__loadedData != null)
            DailyChallengesDataManager.instance.GetLoadedData(__loadedData);
        else
        {
            DailyChallengesDataManager.instance.SetInitialData();
            p_callback(false, "Data loaded failed");
            yield break;
        }


        p_callback(true, "Data loaded successfully");
        yield return null;
    }

    IEnumerator DoSaveDailyChallengesData(Action<bool, string> p_callback)
    {
        DailyChallengeJSONData __saveData = new DailyChallengeJSONData();


        // Pass all data to save here.
        __saveData = DailyChallengesDataManager.instance.SetSaveData();


        // Save challenge data.
        PlayerPrefs.SetString("DATA" + USERS_DAILY_CHALLENGES_DATA_PATH, JsonUtility.ToJson(__saveData));
        PlayerPrefs.SetInt("CHECK" + USERS_DAILY_CHALLENGES_DATA_PATH, 1);


        if (InternetConnectionManager.instance._connected)
            StartCoroutine(cloudDoSaveDailyChallengesData(p_callback));
        else
            p_callback(true, "Data saved successfully");

        yield return null;
    }

    IEnumerator cloudDoSaveDailyChallengesData(Action<bool, string> p_callback)
    {
        string __savePath;
        Task __checkTask;
        float __timer;


        DailyChallengeJSONData __saveData = null;


        // Pass all data to save here.
        __saveData = DailyChallengesDataManager.instance.SetSaveData();


        // Save challenge data.
        __savePath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_DAILY_CHALLENGES_DATA_PATH}";
        __checkTask = _database.GetReference(__savePath).SetRawJsonValueAsync(JsonUtility.ToJson(__saveData));

        __timer = 0;
        while(!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Save data timeout");
            yield break;
        }


        checkDoSaveDailyChallengesData();
        p_callback(true, "Data saved successfully");
        yield return null;
    }

    void checkDoSaveDailyChallengesData()
    {
        // Save challenge data.
        PlayerPrefs.SetInt("CHECK" + USERS_DAILY_CHALLENGES_DATA_PATH, 0);
    }


    IEnumerator DoLoadResetData(Action<bool, string> p_callback)
    {
        string strLoadData = string.Empty;
        string __loadPath;
        Task<DataSnapshot> __checkTask;
        float __timer;


        ResetSaveJSONData __loadedData = null;


        // Load special user data.
        if (DeveloperDatabaseManager.instance._useSpecialUserInfo == true)
        {
            strLoadData = LanguageDataManager.instance.GetSpecialUserData(USERS_RESET_DATA_PATH.Replace("/", ""));
            __loadedData = JsonUtility.FromJson<ResetSaveJSONData>(strLoadData);


            if (__loadedData != null)
                DayResetManager.instance.GetLoadedData(__loadedData);
            else
            {
                DayResetManager.instance.SetInitialData();
                p_callback(false, "Data loaded failed");
                yield break;
            }

            p_callback(true, "Data loaded successfully");
            yield break;
        }


        // Load reset data.
        if (PlayerPrefs.HasKey("DATA" + USERS_RESET_DATA_PATH))
        {
            strLoadData = PlayerPrefs.GetString("DATA" + USERS_RESET_DATA_PATH);
            __loadedData = JsonUtility.FromJson<ResetSaveJSONData>(strLoadData);
        }
        else
        {
            __loadPath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_RESET_DATA_PATH}";
            __checkTask = _database.GetReference(__loadPath).GetValueAsync();

            __timer = 0;
            while (!__checkTask.IsCompleted)
            {
                yield return null;
                __timer += Time.deltaTime;
                if (__timer >= _timeoutTime)
                {
                    break;
                }
            }

            if (__checkTask.IsCompleted)
            {
                if (__checkTask.Result.Exists)
                {
                    __loadedData = JsonUtility.FromJson<ResetSaveJSONData>(__checkTask.Result.GetRawJsonValue());
                }
                else
                {
                    Debug.Log("Data do not exist");
                }
            }
            else
            {
                InternetConnectionManager.instance._connected = false;
                Debug.Log("Load data timeout");
            }
        }

        if (__loadedData != null)
            DayResetManager.instance.GetLoadedData(__loadedData);
        else
        {
            DayResetManager.instance.SetInitialData();
            p_callback(false, "Data loaded failed");
            yield break;
        }


        p_callback(true, "Data loaded successfully");
        yield return null;
    }

    IEnumerator DoSaveResetData(Action<bool, string> p_callback)
    {
        ResetSaveJSONData __saveData = new ResetSaveJSONData();


        // Pass all data to save here.
        __saveData = DayResetManager.instance.SetSaveData();


        // Save reset data.
        PlayerPrefs.SetString("DATA" + USERS_RESET_DATA_PATH, JsonUtility.ToJson(__saveData));
        PlayerPrefs.SetInt("CHECK" + USERS_RESET_DATA_PATH, 1);


        if (InternetConnectionManager.instance._connected)
            StartCoroutine(cloudDoSaveResetData(p_callback));
        else
            p_callback(true, "Data saved successfully");

        yield return null;
    }

    IEnumerator cloudDoSaveResetData(Action<bool, string> p_callback)
    {
        string __savePath;
        Task __checkTask;
        float __timer;


        ResetSaveJSONData __saveData = null;


        // Pass all data to save here.
        __saveData = DayResetManager.instance.SetSaveData();


        // Save reset data.
        __savePath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_RESET_DATA_PATH}";
        __checkTask = _database.GetReference(__savePath).SetRawJsonValueAsync(JsonUtility.ToJson(__saveData));

        __timer = 0;
        while (!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Save data timeout");
            yield break;
        }


        checkDoSaveResetData();
        p_callback(true, "Data saved successfully");
        yield return null;
    }

    void checkDoSaveResetData()
    {
        // Save reset data.
        PlayerPrefs.SetInt("CHECK" + USERS_RESET_DATA_PATH, 0);
    }


    IEnumerator DoLoadShowData(Action<bool, string> p_callback)
    {
        string strLoadData = string.Empty;
        string __loadPath;
        Task<DataSnapshot> __checkTask;
        float __timer;


        PlayerShowJSONData __loadedData = null;


        // Load special user data.
        if (DeveloperDatabaseManager.instance._useSpecialUserInfo == true)
        {
            strLoadData = LanguageDataManager.instance.GetSpecialUserData(USERS_SHOW_DATA_PATH.Replace("/", ""));
            __loadedData = JsonUtility.FromJson<PlayerShowJSONData>(strLoadData);


            if (__loadedData != null)
                PlayerDataManager.instance.playerData.GetShowData(__loadedData);
            else
                PlayerDataManager.instance.playerData.GetShowData(null);

            p_callback(true, "Data loaded successfully");
            yield break;
        }


        // Load show data.
        if (PlayerPrefs.HasKey("DATA" + USERS_SHOW_DATA_PATH))
        {
            strLoadData = PlayerPrefs.GetString("DATA" + USERS_SHOW_DATA_PATH);
            __loadedData = JsonUtility.FromJson<PlayerShowJSONData>(strLoadData);
        }
        else
        {
            __loadPath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_SHOW_DATA_PATH}";
            __checkTask = _database.GetReference(__loadPath).GetValueAsync();

            __timer = 0;
            while (!__checkTask.IsCompleted)
            {
                yield return null;
                __timer += Time.deltaTime;
                if (__timer >= _timeoutTime)
                {
                    break;
                }
            }

            if (__checkTask.IsCompleted)
            {
                if (__checkTask.Result.Exists)
                {
                    __loadedData = JsonUtility.FromJson<PlayerShowJSONData>(__checkTask.Result.GetRawJsonValue());
                }
                else
                {
                    Debug.Log("Data do not exist");
                }
            }
            else
            {
                InternetConnectionManager.instance._connected = false;
                Debug.Log("Load data timeout");
            }
        }


        if (__loadedData != null)
            PlayerDataManager.instance.playerData.GetShowData(__loadedData);
        else
            PlayerDataManager.instance.playerData.GetShowData(null);


        p_callback(true, "Data loaded successfully");
        yield return null;
    }

    IEnumerator DoSaveShowData(Action<bool, string> p_callback)
    {
        PlayerShowJSONData __saveData = new PlayerShowJSONData();


        // Pass all data to save here.
        __saveData = PlayerDataManager.instance.playerData.SetShowData();


        // Save show data.
        PlayerPrefs.SetString("DATA" + USERS_SHOW_DATA_PATH, JsonUtility.ToJson(__saveData));
        PlayerPrefs.SetInt("CHECK" + USERS_SHOW_DATA_PATH, 1);


        if (InternetConnectionManager.instance._connected)
            StartCoroutine(cloudDoSaveShowData(p_callback));
        else
            p_callback(true, "Data saved successfully");

        yield return null;
    }

    IEnumerator cloudDoSaveShowData(Action<bool, string> p_callback)
    {
        string __savePath;
        Task __checkTask;
        float __timer;


        PlayerShowJSONData __saveData = null;


        // Pass all data to save here.
        __saveData = PlayerDataManager.instance.playerData.SetShowData();


        // Save show data.
        __savePath = $"{USERS_PATH}{FirebaseAuthManager.instance.CurrentUser.UserId}{USERS_SHOW_DATA_PATH}";
        __checkTask = _database.GetReference(__savePath).SetRawJsonValueAsync(JsonUtility.ToJson(__saveData));

        __timer = 0;
        while(!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Save data timeout");
            yield break;
        }


        checkDoSaveShowData();
        p_callback(true, "Data saved successfully");
        yield return null;
    }

    void checkDoSaveShowData()
    {
        // Save show data.
        PlayerPrefs.SetInt("CHECK" + USERS_SHOW_DATA_PATH, 0);
    }

    
    IEnumerator DoEraseData(Action<bool, string> p_callback)
    {
        // Erase game prefs.
        PlayerPrefs.SetInt("CHECK" + USERS_PLAYER_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_SCHEDULE_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_PROMOTION_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_BOOSTS_STORE_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_RESET_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_DAILY_CHALLENGES_DATA_PATH, 0);
        PlayerPrefs.SetInt("CHECK" + USERS_SHOW_DATA_PATH, 0);

        PlayerPrefs.DeleteKey("DATA" + USERS_PLAYER_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_SCHEDULE_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_PROMOTION_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_BOOSTS_STORE_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_RESET_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_DAILY_CHALLENGES_DATA_PATH);
        PlayerPrefs.DeleteKey("DATA" + USERS_SHOW_DATA_PATH);


        // Save game prefs
        PlayerPrefs.SetInt("MusicToggle", 1);
        PlayerPrefs.SetInt("SoundToggle", 1);
        PlayerPrefs.SetInt("CommentaryToggle", 1);
        PlayerPrefs.SetInt("FXToggle", 1);

        PlayerPrefs.SetInt("DisableAds", PlayerDataManager.instance.playerData.disableAds ? 1 : 0);
        PlayerPrefs.SetInt("OfflineUse", PlayerDataManager.instance.playerData.offlineUse ? 1 : 0);


        if (InternetConnectionManager.instance._connected)
            StartCoroutine(cloudDoEraseData(p_callback));
        else
            p_callback(true, "Data erased successfully");

        yield return null;
    }

    IEnumerator cloudDoEraseData(Action<bool, string> p_callback)
    {
        Task __checkTask;
        float __timer;


        // Erase data.
        __checkTask = _database.GetReference(USERS_PATH + FirebaseAuthManager.instance.CurrentUser.UserId).RemoveValueAsync();

        __timer = 0;
        while (!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Erase data timeout");
            yield break;
        }


        p_callback(true, "Data erased successfully");
        yield return null;
    }


    IEnumerator DoLoadLeaderboardData(Action<bool, string> p_callback)
    {
        string strLoadData = string.Empty;
        string __loadPath;
        Task<DataSnapshot> __checkTask;
        float __timer;


        float competitionScore = 0;


        if (InternetConnectionManager.instance.IsPublishCompetition() == false)
        {
            p_callback(true, "Data loaded successfully");
            yield break;
        }

        // Load special user data.
        if (DeveloperDatabaseManager.instance._useSpecialUserInfo == true)
        {
            PlayerDataManager.instance.playerData.setCompetitionScore(competitionScore);
            
            p_callback(true, "Data loaded successfully");
            yield break;
        }


        // Load show data.
        if (PlayerPrefs.HasKey("DATA" + LEADERBOARD_PATH + InternetConnectionManager.instance.currentCompetitionName()))
        {
            competitionScore = PlayerPrefs.GetFloat("DATA" + LEADERBOARD_PATH + InternetConnectionManager.instance.currentCompetitionName());
            PlayerDataManager.instance.playerData.setCompetitionScore(competitionScore);
        }
        else
        {
            __loadPath = $"{LEADERBOARD_PATH}{InternetConnectionManager.instance.currentCompetitionName()}{"/"}{FirebaseAuthManager.instance.CurrentUser.UserId}";
            __checkTask = _database.GetReference(__loadPath).GetValueAsync();

            __timer = 0;
            while (!__checkTask.IsCompleted)
            {
                yield return null;
                __timer += Time.deltaTime;
                if (__timer >= _timeoutTime)
                {
                    break;
                }
            }

            if (__checkTask.IsCompleted)
            {
                if (__checkTask.Result.Exists)
                {
                    strLoadData = __checkTask.Result.GetRawJsonValue();
                    PlayerLeaderboardJSONData myData = JsonUtility.FromJson<PlayerLeaderboardJSONData>(strLoadData);
                    competitionScore = myData.fScore;
                }
                else
                {
                    Debug.Log("Data do not exist");
                }
            }
            else
            {
                InternetConnectionManager.instance._connected = false;
                Debug.Log("Load data timeout");
            }
        }


        PlayerDataManager.instance.playerData.setCompetitionScore(competitionScore);
        p_callback(true, "Data loaded successfully");
        yield return null;
    }

    IEnumerator DoSaveLeaderboardData(Action<bool, string> p_callback)
    {
        float competitionScore = 0;


        // Pass all data to save here.
        if (InternetConnectionManager.instance.IsPeriodCompetition() == false)
        {
            p_callback(true, "Data saved successfully");
            yield break;
        }

        competitionScore = PlayerDataManager.instance.playerData.getCompetitionScore();


        // Save show data.
        if (competitionScore <= 0)
        {
            p_callback(true, "Data saved successfully");
            yield break;
        }

        PlayerPrefs.SetFloat("DATA" + LEADERBOARD_PATH + InternetConnectionManager.instance.currentCompetitionName(), competitionScore);
        PlayerPrefs.SetInt("CHECK" + LEADERBOARD_PATH + InternetConnectionManager.instance.currentCompetitionName(), 1);


        if (InternetConnectionManager.instance._connected)
            StartCoroutine(cloudDoSaveLeaderboardData(p_callback));
        else
            p_callback(true, "Data saved successfully");

        yield return null;
    }

    IEnumerator cloudDoSaveLeaderboardData(Action<bool, string> p_callback)
    {
        string strSaveData;
        string __savePath;
        Task __checkTask;
        float __timer;


        // Pass all data to save here.
        PlayerLeaderboardJSONData saveData = new PlayerLeaderboardJSONData();
        saveData.strUserName = PlayerDataManager.instance.playerData.playerName;
        saveData.nStyle = (int)PlayerDataManager.instance.playerData.wrestlingStyle;
        saveData.fScore = PlayerDataManager.instance.playerData.getCompetitionScore();
        strSaveData = JsonUtility.ToJson(saveData);


        // Save show data.
        if (saveData.fScore <= 0)
        {
            p_callback(true, "Data saved successfully");
            yield break;
        }

        __savePath = $"{LEADERBOARD_PATH}{InternetConnectionManager.instance.currentCompetitionName()}{"/"}{FirebaseAuthManager.instance.CurrentUser.UserId}";
        __checkTask = _database.GetReference(__savePath).SetRawJsonValueAsync(strSaveData);

        __timer = 0;
        while (!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Exception != null)
            {
                p_callback(false, __checkTask.Exception.Message);
                yield break;
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            p_callback(false, "Save data timeout");
            yield break;
        }


        checkDoSaveLeaderboardData();
        p_callback(true, "Data saved successfully");
        yield return null;
    }

    void checkDoSaveLeaderboardData()
    {
        // Save show data.
        PlayerPrefs.SetInt("CHECK" + LEADERBOARD_PATH + InternetConnectionManager.instance.currentCompetitionName(), 0);
    }


    public void LoadRankingLastLeaderboard(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoLoadRankingLastLeaderboard(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }

    IEnumerator DoLoadRankingLastLeaderboard(Action<bool, string> p_callback)
    {
        Dictionary<string, object> dicLoadData = null;
        string __loadPath;
        Task<DataSnapshot> __checkTask;
        float __timer;


        PlayerDataManager.instance.playerData._bPickLeaderboardReward = 0;
        PlayerDataManager.instance.playerData._lastWinnerName = String.Empty;

        if (InternetConnectionManager.instance.IsPublishCompetition() == false)
        {
            p_callback(true, "Data loaded successfully");
            yield break;
        }

        __loadPath = $"{LEADERBOARD_PATH}{InternetConnectionManager.instance.lastCompetitionName()}";
        __checkTask = _database.GetReference(__loadPath).GetValueAsync();

        __timer = 0;
        while (!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Result.Exists)
            {
                if (__checkTask.Result.Value != null)
                {
                    if (__checkTask.Result.ChildrenCount > 0)
                    {
                        dicLoadData = (Dictionary<string, object>)__checkTask.Result.Value;
                    }
                    else
                        Debug.Log("Data is empty");
                }
                else
                    Debug.Log("Data do not valid");
            }
            else
            {
                Debug.Log("Data do not exist");
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            Debug.Log("Load data timeout");
        }

        PlayerDataManager.instance.playerData._bPickLeaderboardReward = 0;
        if (dicLoadData == null)
        {
            p_callback(true, "Data loaded failed");
            yield break;
        }

        if (dicLoadData.Count < 1)
        {
            p_callback(true, "Data loaded failed");
            yield break;
        }

        string strWinnerID = string.Empty;
        string strWinnerName = string.Empty;

        List<PlayerData.LeaderboardScoreList> scoreList = new List<PlayerData.LeaderboardScoreList>();
        foreach (var objCompetition in dicLoadData)
        {
            if (objCompetition.Value == null)
                continue;

            Dictionary<string, object> dicRankingInfo = (Dictionary<string, object>)objCompetition.Value;
            if (dicRankingInfo == null)
                continue;

            if (dicRankingInfo.Count < 2)
                continue;


            object objTempValue;
            if (dicRankingInfo.TryGetValue("strUserName", out objTempValue) == false)
                continue;
            string strName = objTempValue.ToString();

            if (dicRankingInfo.TryGetValue("nStyle", out objTempValue) == false)
                continue;
            int nStyle = Convert.ToInt32(objTempValue);

            if (dicRankingInfo.TryGetValue("fScore", out objTempValue) == false)
                continue;
            float fScore = Convert.ToSingle(objTempValue);


            scoreList.Add(new PlayerData.LeaderboardScoreList(objCompetition.Key, strName, nStyle, fScore));
        }

        List<PlayerData.LeaderboardScoreList> sortedList = scoreList.OrderByDescending(score => score.fScores).ToList();
        if (sortedList != null)
        {
            if (sortedList.Count > 0)
            {
                PlayerDataManager.instance.playerData._lastWinnerName = sortedList[0].strUserName;
                
                int myRanking = sortedList.FindIndex(result => result.strUserID == FirebaseAuthManager.instance.CurrentUser.UserId);
                PlayerData.LeaderboardScoreList myInfo = sortedList.Find(result => result.strUserID == FirebaseAuthManager.instance.CurrentUser.UserId);
                if (myInfo != null)
                {
                    PlayerDataManager.instance.playerData._lastMyfScore = myInfo.fScores;
                    PlayerDataManager.instance.playerData._lastMyRanking = ++myRanking;

                    if (myRanking == 1)
                    {
                        PlayerData.Championship championship = new PlayerData.Championship();
                        championship.promotion = new PromotionData();
                        championship.promotion.promotionName = "Indie Wrestler";
                        championship.count = 1;

                        PlayerDataManager.instance.playerData.championships.Insert(0, championship);
                    }

                    if (0 < myRanking && myRanking < 501 && PlayerDataManager.instance.playerData.GetLeaderboardInfoOfName(InternetConnectionManager.instance.lastCompetitionName()) == null)
                        PlayerDataManager.instance.playerData._bPickLeaderboardReward = 1;
                }
            }
        }

        p_callback(true, "Data loaded successfully");
        yield return null;
    }

    public void LoadRankingLeaderboard(Action<bool, string> p_callback)
    {
        if (_isInitialized)
        {
            StartCoroutine(DoLoadRankingLeaderboard(p_callback));
        }
        else
        {
            p_callback(false, "Operation Failed");
        }
    }

    IEnumerator DoLoadRankingLeaderboard(Action<bool, string> p_callback)
    {
        Dictionary<string, object> dicLoadData = null;
        string __loadPath;
        Task<DataSnapshot> __checkTask;
        float __timer;


        if (InternetConnectionManager.instance.IsPublishCompetition() == false)
        {
            p_callback(true, "Data loaded successfully");
            yield break;
        }

        __loadPath = $"{LEADERBOARD_PATH}{InternetConnectionManager.instance.currentCompetitionName()}";
        __checkTask = _database.GetReference(__loadPath).GetValueAsync();

        __timer = 0;
        while (!__checkTask.IsCompleted)
        {
            yield return null;
            __timer += Time.deltaTime;
            if (__timer >= _timeoutTime)
            {
                break;
            }
        }

        if (__checkTask.IsCompleted)
        {
            if (__checkTask.Result.Exists)
            {
                if (__checkTask.Result.Value != null)
                {
                    if (__checkTask.Result.ChildrenCount > 0)
                    {
                        dicLoadData = (Dictionary<string, object>)__checkTask.Result.Value;
                    }
                    else
                        Debug.Log("Data is empty");
                }
                else
                    Debug.Log("Data do not valid");
            }
            else
            {
                Debug.Log("Data do not exist");
            }
        }
        else
        {
            InternetConnectionManager.instance._connected = false;
            Debug.Log("Load data timeout");
        }

        if (dicLoadData == null)
        {
            p_callback(true, "Data loaded failed");
            yield break;
        }

        if (dicLoadData.Count < 1)
        {
            p_callback(true, "Data loaded failed");
            yield break;
        }

        List<PlayerData.LeaderboardScoreList> scoreList = new List<PlayerData.LeaderboardScoreList>();
        foreach (var objCompetition in dicLoadData)
        {
            if (objCompetition.Value == null)
                continue;

            Dictionary<string, object> dicRankingInfo = (Dictionary<string, object>)objCompetition.Value;
            if (dicRankingInfo == null)
                continue;

            if (dicRankingInfo.Count < 2)
                continue;


            object objTempValue;
            if (dicRankingInfo.TryGetValue("strUserName", out objTempValue) == false)
                continue;
            string strName = objTempValue.ToString();

            if (dicRankingInfo.TryGetValue("nStyle", out objTempValue) == false)
                continue;
            int nStyle = Convert.ToInt32(objTempValue);

            if (dicRankingInfo.TryGetValue("fScore", out objTempValue) == false)
                continue;
            float fScore = Convert.ToSingle(objTempValue);


            scoreList.Add(new PlayerData.LeaderboardScoreList(objCompetition.Key, strName, nStyle, fScore));
        }

        PlayerDataManager.instance.playerData.setCompetitionScoreList(scoreList.OrderByDescending(score => score.fScores).ToList());
        p_callback(true, "Data loaded successfully");
        yield return null;
    }
}
