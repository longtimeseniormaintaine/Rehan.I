﻿using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using System;
using System.Globalization;

public class InternetConnectionManager : MonoBehaviour
{
    public Action<int> gameOffline;
    [HideInInspector]
    public bool _connected = false;
    [HideInInspector]
    public DateTime _nowGoogleUtcTime;
    [HideInInspector]
    public TimeSpan _timespanFromUtc;
    

    [HideInInspector]
    public static InternetConnectionManager instance;

    [Header("InternetConnection")]
    [SerializeField] float _CheckConnectionInterval = 10;
    [Header("Competition")]
    [SerializeField] DayOfWeek _CompetitionDays = DayOfWeek.Sunday;
    [SerializeField] [Range(0f, 24f)] float _CompetitionExitHour = 17.0f;
    [SerializeField] [Range(0f, 24f)] float _CompetitionStartHour = 19.0f;

    string _pingUrl = "https://google.com";
    int _status;
    DateTime _datePublishCompetition;

    void Awake() {
        if (instance == null)
        {
            instance = this;
            _status = 0;
        }
        else
        {
            Debug.LogWarning("Multiple InternetConnectionManager!");
            Destroy(gameObject);
        }
    }

    public void CheckInternetConnection(Action<bool> p_callback)
    {
        StartCoroutine(PingUrl(p_callback));
    }

    IEnumerator PingUrl(Action<bool> p_callback)
    {
        UnityWebRequest __request = UnityWebRequest.Get(_pingUrl);
        yield return __request.SendWebRequest();

        if (__request.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(__request.error);
            _connected = false;
            p_callback?.Invoke(false);
        }
        else
        {
            _connected = true;
            _nowGoogleUtcTime = TimeZoneInfo.ConvertTimeToUtc(DateTime.ParseExact(__request.GetResponseHeader("date"), "ddd, dd MMM yyyy HH:mm:ss 'GMT'", CultureInfo.InvariantCulture.DateTimeFormat, DateTimeStyles.AssumeUniversal));
            _timespanFromUtc = _nowGoogleUtcTime - DateTime.Now;
            p_callback?.Invoke(true);
        }
    }

    public void CheckInternetConnectionRealTime()
    {
        if (_status == 0)
            StartCoroutine(ConstantlyCheckConnection());
        else if (_status == 2)
            _status = 1;
    }

    IEnumerator ConstantlyCheckConnection()
    {
        _status = 1;

        while(true)
        {
            yield return new WaitForSeconds(_CheckConnectionInterval);

            if (_status == 2)
                continue;
            else if (_status == 3)
            {
                _status = 0;
                break;
            }
            
            CheckInternetConnection(ProcessConnectionError);
        }
        // ReSharper disable once IteratorNeverReturns
    }

    void ProcessConnectionError(bool p_success)
    {
        if (p_success)
            return;

        if (PlayerDataManager.instance.playerData.offlineUse == true)
        {
            _status = 2;
            return;
        }

        gameOffline?.Invoke(0);
    }


    public void SetPublishCompetitionDate(LeaderboardDeveloperJSONData jsonPublishDate)
    {
        _datePublishCompetition = DateTime.Parse(jsonPublishDate.PublishDate);
    }

    public bool IsPublishCompetition()
    {
        DateTime dtLocationNow = DateTime.Now.Add(_timespanFromUtc);

        if (dtLocationNow < _datePublishCompetition)
            return false;

        return true;
    }

    public TimeSpan remainPublishTime()
    {
        DateTime dtLocationNow = DateTime.Now.Add(_timespanFromUtc);
        TimeSpan remainResult = _datePublishCompetition - dtLocationNow;

        return remainResult;
    }


    public bool IsPeriodCompetition()
    {
        if (!IsPublishCompetition())
            return false;

        DateTime dtLocationNow = DateTime.Now.Add(_timespanFromUtc);

        if (dtLocationNow.DayOfWeek != _CompetitionDays)
            return true;

        TimeSpan nowTime = dtLocationNow.TimeOfDay;
        if (_CompetitionExitHour < nowTime.TotalHours && nowTime.TotalHours < _CompetitionStartHour)
            return false;

        return true;
    }

    public TimeSpan remainStartTime()
    {
        if (!IsPublishCompetition())
            return remainPublishTime();

        DateTime dtLocationNow = DateTime.Now.Add(_timespanFromUtc);
        TimeSpan remainResult;

        if (dtLocationNow.DayOfWeek != _CompetitionDays ||
            dtLocationNow.TimeOfDay.TotalHours > _CompetitionStartHour ||
            dtLocationNow.TimeOfDay.TotalHours < _CompetitionExitHour)
        {
            remainResult = new TimeSpan();
        }
        else
        {
            TimeSpan remainTime = new TimeSpan(0, (int)_CompetitionStartHour, 0, 0) - dtLocationNow.TimeOfDay;
            remainResult = remainTime;
        }

        return remainResult;
    }

    public TimeSpan remainEndTime()
    {
        DateTime dtLocationNow = DateTime.Now.Add(_timespanFromUtc);
        TimeSpan remainResult;

        if (dtLocationNow.DayOfWeek != _CompetitionDays)
        {
            int nDays = 6 - (int)dtLocationNow.DayOfWeek;
            TimeSpan remainDays = new TimeSpan(nDays, (int)_CompetitionExitHour, 0, 0);
            TimeSpan remainTime = new TimeSpan(1, 0, 0, 0) - dtLocationNow.TimeOfDay;
            remainResult = remainDays + remainTime;
        }
        else if (dtLocationNow.TimeOfDay.TotalHours > _CompetitionStartHour)
        {
            TimeSpan remainDays = new TimeSpan(7, (int)_CompetitionExitHour, 0, 0);
            TimeSpan remainTime = new TimeSpan(1, 0, 0, 0) - dtLocationNow.TimeOfDay;
            remainResult = remainDays + remainTime;
        }
        else if (dtLocationNow.TimeOfDay.TotalHours < _CompetitionExitHour)
        {
            int nDays = 7 - (int)dtLocationNow.DayOfWeek;
            TimeSpan remainTime = new TimeSpan(0, (int)_CompetitionExitHour, 0, 0) - dtLocationNow.TimeOfDay;
            remainResult = remainTime;
        }
        else
            remainResult = new TimeSpan();

        return remainResult;
    }

    public string currentCompetitionName()
    {
        DateTime dtLocationNow = DateTime.Now.Add(_timespanFromUtc);
        int nDayOfYear = (dtLocationNow.DayOfYear > (int)dtLocationNow.DayOfWeek) ? dtLocationNow.DayOfYear - (int)dtLocationNow.DayOfWeek : (DateTime.IsLeapYear(dtLocationNow.Year - 1) ? 366 : 365) + dtLocationNow.DayOfYear - (int)dtLocationNow.DayOfWeek;
        int nWeekOfYear = (nDayOfYear) / 7;
        string strLeaderboardIndex = string.Empty;

        if (dtLocationNow.DayOfWeek != _CompetitionDays)
        {
            strLeaderboardIndex = dtLocationNow.Year + "-" + nWeekOfYear;
        }
        else if (dtLocationNow.TimeOfDay.TotalHours > _CompetitionStartHour)
        {
            strLeaderboardIndex = dtLocationNow.Year + "-" + nWeekOfYear;
        }
        else
        {
            strLeaderboardIndex = dtLocationNow.Year + "-" + (((nWeekOfYear > 1) ? nWeekOfYear : 1) - 1);
        }

        return strLeaderboardIndex;
    }

    public string lastCompetitionName()
    {
        DateTime dtLocationNow = DateTime.Now.Add(_timespanFromUtc);
        int nDayOfYear = (dtLocationNow.DayOfYear > (int)dtLocationNow.DayOfWeek) ? dtLocationNow.DayOfYear - (int)dtLocationNow.DayOfWeek : (DateTime.IsLeapYear(dtLocationNow.Year - 1) ? 366 : 365) + dtLocationNow.DayOfYear - (int)dtLocationNow.DayOfWeek;
        int nWeekOfYear = (nDayOfYear) / 7;
        string strLeaderboardIndex = string.Empty;

        if (nWeekOfYear < 1)
            return strLeaderboardIndex;

        if (dtLocationNow.DayOfWeek != _CompetitionDays)
        {
            strLeaderboardIndex = dtLocationNow.Year + "-" + (((nWeekOfYear > 1) ? nWeekOfYear : 1) - 1);
        }
        else if (dtLocationNow.TimeOfDay.TotalHours > _CompetitionExitHour)
        {
            strLeaderboardIndex = dtLocationNow.Year + "-" + (((nWeekOfYear > 1) ? nWeekOfYear : 1) - 1);
        }
        else
        {
            strLeaderboardIndex = dtLocationNow.Year + "-" + (((nWeekOfYear > 2) ? nWeekOfYear : 2) - 2);
        }

        return strLeaderboardIndex;
    }

    public TimeSpan remainExitTimeForItem(int nMonth)
    {
        DateTime dtLocationNow = DateTime.Now.Add(_timespanFromUtc);
        TimeSpan remainResult;

        if (dtLocationNow.Month - nMonth > 1)
        {
            remainResult = new TimeSpan();
        }
        else
        {
            int nLastDay = DateTime.DaysInMonth(dtLocationNow.Year, (dtLocationNow.Month < 12) ? dtLocationNow.Month + 1 : dtLocationNow.Month);
            remainResult = new TimeSpan(nLastDay, 23, 59, 59) - new TimeSpan(dtLocationNow.Day, dtLocationNow.Hour, dtLocationNow.Minute, dtLocationNow.Second);
        }
        
        return remainResult;
    }
}
