﻿using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;
using Random = UnityEngine.Random;

[CreateAssetMenu(fileName = "Promotion Data", menuName = "Data/Promotion Data")]
public class PromotionData : ScriptableObject
{
    [Serializable]
    public class MatchRecord
    {
        public float score;
        public WrestlerData opponent;
        public DateTime eventDate;
        public string eventName;
        public bool won;

        public MatchRecord()
        {

        }

        public MatchRecord(MatchRecord p_matchRecord)
        {
            score = p_matchRecord.score;
            opponent = p_matchRecord.opponent;
            eventDate = p_matchRecord.eventDate;
            eventName = p_matchRecord.eventName;
            won = p_matchRecord.won;
        }
    }
    
    [Header("Promotion Info")]
    public string promotionName;
    public string promotionInitials;

    public Sprite PromotionLogo
    {
        get
        {
            var __logoPath = $"Promotions/Assets/promotion_{promotionName}_logo";
            return ImageLoader.LoadSpriteFromResources(__logoPath);
        }
    }

    public string promotionFoundedYear;
    public string promotionStreamingPartner;

    public Sprite PromotionPartnerMark
    {
        get
        {
            var __markPath = $"Promotions/Partners/{promotionStreamingPartner}";
            return ImageLoader.LoadSpriteFromResources(__markPath);
        }
    }

    [Header("Promotion Game Data")]
    public Enums.PromotionRegion promotionRegion;
    public Enums.PromotionCountry promotionCountry;
    public int milesCost;
    public int milesSpent;
    public bool isUnlocked = false;
    public bool hadContractBefore = false;
    public Enums.Position playerPosition = Enums.Position.OPENER;
    
    #region Unlock Levels

    public int promotionUnlockLevel;
    public int promotionUnlockLowerCard;
    public int promotionUnlockMidCard;
    public int promotionUnlockUpperCard;
    public int promotionUnlockMainEvent;
    
    #endregion

    #region Salaries

    public int promotionSalaryOpener;
    public int promotionSalaryLowerCard;
    public int promotionSalaryMidCard;
    public int promotionSalaryUpperCard;
    public int promotionSalaryMainEvent;
    public int promotionSalaryChampion;

    #endregion

    public bool playerIsChampion = false;
    public bool playerIsMidTitleChampion = false;
    public bool isFirstMatch = true;
    public bool isInitialMatchStreak = true;
    public void AddShowRating(float p_rating) {
        _showRatings.Add(p_rating);
        if (_showRatings.Count > 4)
        {
            _showRatings.RemoveAt(0);
        }

        float __sum = 0;
        foreach (var __rating in _showRatings)
        {
            __sum += __rating;
        }
        promotionPerformance = __sum / 4f;
    }
    public List<float> GetShowRatings()
    {
        return new List<float>(_showRatings);
    }
    public void AddShowResult(float score, WrestlerData opponent, DateTime eventDate, string eventName, int mode, bool won, int championlevel, bool dqmatch = false)
    {
        PromotionResultInfo record = new PromotionResultInfo();
        record.score = score;
        record.opponent = opponent.wrestlerName;
        record.totalDays = DateManager.instance.GetTotalDaysFromDate(eventDate);
        record.eventName = eventName;
        record.mode = mode;
        record.won = won;
        record.championlevel = championlevel;

        _showResults.Add(record);

        //Competition
        if (InternetConnectionManager.instance.IsPeriodCompetition() == false)
            return;

        float fCompetitionScore = PlayerDataManager.instance.playerData.getCompetitionScore();
        fCompetitionScore += score * 10;
        if (mode == (int)Enums.PromotionType.MATCH)
        {
            if (dqmatch)
                fCompetitionScore += 15;
            else
                fCompetitionScore += (won == true) ? 25 : 5;
        }

        if (PlayerDataManager.instance.playerData.equippedOutfit != null)
        {
            if (PlayerDataManager.instance.playerData.equippedOutfit.leaderboard == true)
            {
                DateTime dtLocationNow = DateTime.Now.Add(InternetConnectionManager.instance._timespanFromUtc);
                int nCurrentMonth = dtLocationNow.Month;
                int nUsingMonth = PlayerDataManager.instance.playerData.equippedOutfit.usingMonth;

                if (nCurrentMonth == nUsingMonth)
                    fCompetitionScore += 30;
                else if (nCurrentMonth == nUsingMonth + 1)
                    fCompetitionScore += 10;
            }
        }

        PlayerDataManager.instance.playerData.setCompetitionScore(fCompetitionScore);
        PlayerDataManager.instance.playerData.UpdateMyCompetitionRanking();
    }
    public void SetShowResults(List<PromotionResultInfo> results)
    {
        _showResults = results;
    }
    public List<PromotionResultInfo> GetShowResults()
    {
        return new List<PromotionResultInfo>(_showResults.FindAll(result => result.mode != 0));
    }
    public float promotionPerformance;
    [SerializeField] List<float> _showRatings = new List<float>();
    [SerializeField] List<PromotionResultInfo> _showResults = new List<PromotionResultInfo>();
    public bool hasPermissionToCancelBooking = false;
    public int noShowCount = 0;

    #region Promoter

    [Header("Promoter Info")]
    public string promoterName;
    public int PromoterHappiness
    {
        get { return promoterHappiness; }
        set 
        { 
            if (value < 0)
            {
                promoterHappiness = 0;
            }
            else if (value > 100)
            {
                promoterHappiness = 100;
            }
            else 
            {
                promoterHappiness = value;
            }
        }
    }
    [SerializeField] [Range(0, 100)] int promoterHappiness;

    #endregion

    #region Contract

    [Header("Contract Info")]
    public bool hasContract;
    public int contractPayPerMatch;
    public int contractDays
    {
        get { return _contractDates; }
        set 
        {
            _contractDates = value;
            contractDaysLeft = _contractDates;
            contractDaysToSchedule = _contractDates;
        }
    }
    public int contractDaysLeft
    {
        get { return _contractDatesLeft; }
        set
        {
            _contractDatesLeft = value;
            if (_contractDatesLeft == 0)
            {
                hasContract = false;
                hasPermissionToCancelBooking = false;
                _contractDates = 0;
                _contractDatesToSchedule = 0;
            }
        }
    }
    public int contractDaysToSchedule
    {
        get { return _contractDatesToSchedule; }
        set 
        {
            _contractDatesToSchedule = value;
            _contractDatesToSchedule = Mathf.Clamp(_contractDatesToSchedule, 0, _contractDatesLeft);
        }
    }
    [SerializeField] int _contractDates = 0;
    [SerializeField] int _contractDatesLeft = 0;
    [SerializeField] int _contractDatesToSchedule = 0;
    public Enums.Position contractPosition;
    public Enums.Disposition contractDisposition;

    public void ReleaseContract()
    {
        contractDays = 0;
        if (playerIsChampion)
        {
            roster[Random.Range(0, roster.Count)].isChampion = true;
            playerIsChampion = false;
        }
    }

    #endregion

    [Header("Event Info")]
    public string eventName;
    public string eventLocation;
    public Enums.WeekDay eventWeekday;

    #region Roster

    [Serializable]
    public class PromotionWrestlerData 
    {
        public WrestlerData wrestlerData;
        public bool isChampion;
        public bool isMidTitleChampion;
        public string tagTeam;
    }
    [Header("Roster Info")]
    public List<PromotionWrestlerData> roster = new List<PromotionWrestlerData>();
    
    public PromotionWrestlerData PromotionChampion
    {
        get
        {
            return roster.FirstOrDefault(__wrestler => __wrestler.isChampion);
        }
    }
    
    public PromotionWrestlerData MidTitleChampion
    {
        get
        {
            return roster.FirstOrDefault(__wrestler => __wrestler.isMidTitleChampion);
        }
    }
    
    public List<PromotionWrestlerData> PromotionRosterWithoutChampion
    {
        get
        {
            return roster.Where(wrestler => !wrestler.isChampion).ToList();
        }
    }

    public List<PromotionWrestlerData> PromotionRosterWithoutMidTitleChampion
    {
        get
        {
            return roster.Where(wrestler => !wrestler.isMidTitleChampion).ToList();
        }
    }
    
    public List<PromotionWrestlerData> PromotionRosterWithoutChampions
    {
        get
        {
            return roster.Where(wrestler => !wrestler.isChampion && !wrestler.isMidTitleChampion).ToList();
        }
    }
    
    public PromotionWrestlerData GetWrestlerFromName(string p_name)
    {
        foreach (var __wrestler in roster)
        {
            if (string.Equals(__wrestler.wrestlerData.wrestlerName, p_name))
            {
                return __wrestler;
            }
        }
        return null;
    }

    public void SetChampion(string p_name)
    {
        if (string.IsNullOrEmpty(p_name))
        {
            foreach (var __wrestler in roster)
            {
                __wrestler.isChampion = false;
            }
        }
        else
        {
            foreach (var __wrestler in roster)
            {
                __wrestler.isChampion = string.Equals(__wrestler.wrestlerData.wrestlerName, p_name);
            }
        }
    }
    
    public void SetMidTitleChampion(string p_name)
    {
        if (string.IsNullOrEmpty(p_name))
        {
            foreach (var __wrestler in roster)
            {
                __wrestler.isMidTitleChampion = false;
            }
        }
        else
        {
            foreach (var __wrestler in roster)
            {
                __wrestler.isMidTitleChampion = string.Equals(__wrestler.wrestlerData.wrestlerName, p_name);
            }
        }

        // Fix for existing players that do not have any cached info on Mid Titles
        if (HasMidTitle && !playerIsMidTitleChampion && MidTitleChampion == null)
        {
            var __text = Resources.Load<TextAsset>("Promotions/PromotionsInfo");
            var __promotionsInfo = JsonUtility.FromJson<PromotionsInfoJSONData>(__text.text);

            var __promotionJsonData =
                __promotionsInfo.Promotions.FirstOrDefault(p_promotion => p_promotion.PromotionInfo.Name == promotionName);
            var __midTitleChampion =
                __promotionJsonData?.RosterInfo.FirstOrDefault(p_wrestler => p_wrestler.IsMidTitleChampion);
            if (__midTitleChampion == null)
            {
                return;
            }
            var __wrestler = roster.FirstOrDefault(p_existingWrestler => p_existingWrestler.wrestlerData.wrestlerName == __midTitleChampion.Name);
            if (__wrestler != null)
            {
                __wrestler.isMidTitleChampion = true;
            }
        }
    }

    #endregion

    public Sprite TitleBelt
    {
        get
        {
            
            var __beltPath = $"Promotions/Assets/promotion_{promotionName}_belt";
            return ImageLoader.LoadSpriteFromResources(__beltPath);
        }
    }
    public Sprite MidTitleBelt
    {
        get
        {
            var __beltPath = $"Promotions/Assets/promotion_{promotionName}_mid_belt";
            return ImageLoader.LoadSpriteFromResources(__beltPath);
        }
    }

    public string midTitleName;

    public bool HasMidTitle => !string.IsNullOrEmpty(midTitleName);

    #region Match History

    [Header("Match History")]

    public int matchWinCount = 0;
    public int matchLossCount = 0;
    public MatchRecord HighestMatch 
    {
        get { return _highestMatch; }
        set { _highestMatch = value; }
    }
    public MatchRecord LowestMatch
    {
        get { return _lowestMatch; }
        set { _lowestMatch = value; }
    }
    public MatchRecord LastMatch
    {
        get { return _lastMatch; }
        set { _lastMatch = value; }
    }
    [SerializeField] MatchRecord _highestMatch = null;
    [SerializeField] MatchRecord _lowestMatch = null;
    [SerializeField] MatchRecord _lastMatch = null;
    
    public void AddMatch(float p_score, WrestlerData p_opponent, DateTime p_eventDate, string p_eventName, bool p_won)
    {
        if (_lastMatch == null)
        {
            _lastMatch = new MatchRecord();
        }
        _lastMatch.score = p_score;
        _lastMatch.opponent = p_opponent;
        _lastMatch.eventDate = p_eventDate;
        _lastMatch.eventName = p_eventName;
        _lastMatch.won = p_won;

        if (_highestMatch != null)
        {
            if (_highestMatch.opponent == null || _lastMatch.score >= _highestMatch.score)
            {
                _highestMatch = new MatchRecord(_lastMatch);
            }
        }
        else
        {
            _highestMatch = new MatchRecord(_lastMatch);
        }

        if (_lowestMatch != null)
        {
            if (_lowestMatch.opponent == null || _lastMatch.score <= _lowestMatch.score)
            {
                _lowestMatch = new MatchRecord(_lastMatch);
            }
        }
        else
        {
            _lowestMatch = new MatchRecord(_lastMatch);
        }
    }

    public void ResetMatch()
    {
        _lastMatch = null;
        _highestMatch = null;
        _lastMatch = null;
    }

    #endregion
}
