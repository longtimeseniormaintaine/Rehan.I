﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[Serializable]
public class PromotionResultInfo
{
    public float score;
    public string opponent;
    public int totalDays;
    public string eventName;
    public int mode;
    public bool won;
    public int championlevel;

    public PromotionResultInfo()
    {

    }
}

